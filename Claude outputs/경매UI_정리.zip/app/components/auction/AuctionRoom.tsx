"use client";

// =============================================================
// 경매 진행 화면 (팀장 입찰 / 운영진 진행)
// - 0.5초마다 세션 상태를 폴링한다.
// - 낙찰/다음 처리 흐름(awarded, frozenPlayer, awardCd ...)은 기존 동작을 그대로 유지한다.
// =============================================================

import { useCallback, useEffect, useRef, useState } from "react";
import AuctionTimer from "./AuctionTimer";
import {
  ChampImg, LineIcon, TierText, LINES, LINE_LABEL, TEAM_COLORS,
  type AuctionBid, type AuctionPlayer, type AuctionSession,
} from "./shared";

const BID_STEPS = [5, 10, 50, 100] as const;
const teamVar = (color: string) => ({ ["--team" as string]: color }) as React.CSSProperties;

export default function AuctionRoom({sessionId,isAdmin,myUserId}:{sessionId:number;isAdmin:boolean;myUserId:number|null}){
  const [session,setSession]=useState<AuctionSession|null>(null);
  const [players,setPlayers]=useState<AuctionPlayer[]>([]);
  const [bids,setBids]=useState<AuctionBid[]>([]);
  const [serverNow,setServerNow]=useState<number|null>(null);
  const [bidErr,setBidErr]=useState("");
  const [bidLoading,setBidLoading]=useState(false);
  const [awarded,setAwarded]=useState(false);
  const [awardedTopBid,setAwardedTopBid]=useState<AuctionBid|null>(null);
  const [frozenPlayer,setFrozenPlayer]=useState<AuctionPlayer|null>(null);
  const [awardCd,setAwardCd]=useState<number|null>(null);
  const [nexting,setNexting]=useState(false);
  const pollRef=useRef<ReturnType<typeof setInterval>|null>(null);
  const prevTopRef=useRef<number>(0);
  const timerResetRef=useRef<(()=>void)|null>(null);
  const prevPlayerIdRef=useRef<number|null>(null);
  const nextingRef=useRef(false);
  const awardingRef=useRef(false);
  const captains=players.filter(p=>p.is_captain===1);
  const nonCaptains=players.filter(p=>p.is_captain===0);
  const timerStartedAt=session?.timer_started?(session.timer_started_at??null):null;
  const currentPlayer=session?nonCaptains.filter(p=>p.team_id===null)[0]??null:null;
  // 낙찰 표시: awarded state(어드민) 또는 timer_started=0이고 frozenPlayer가 있으면(팀장)
  const displayPlayer=awarded?frozenPlayer:currentPlayer;
  const activePlayer=displayPlayer??currentPlayer;
  const bidSourcePlayer=awarded?frozenPlayer:currentPlayer;
  const currentBids=bidSourcePlayer?bids.filter(b=>b.player_id===bidSourcePlayer.id):[];
  const topBid=awarded?awardedTopBid:currentBids.reduce<AuctionBid|null>((top,b)=>(!top||b.points>top.points)?b:top,null);
  // 챔피언 공개 조건: 어드민은 awarded&&awardedTopBid, 팀장은 awarded&&topBid
  const champRevealed=awarded&&(awardedTopBid??topBid)!=null;
  const topBidRef=useRef(topBid);topBidRef.current=topBid;
  const sessionRef=useRef(session);sessionRef.current=session;
  const myCaptain=myUserId?captains.find(c=>c.user_id===myUserId)??null:null;
  const awardedRef=useRef(false);
  awardedRef.current=awarded;
  const myUserIdRef=useRef(myUserId);myUserIdRef.current=myUserId;
  const prevCurrentIdxRef=useRef<number|null>(null);
  const prevTimerStartedRef=useRef<number|null>(null);
  const load=useCallback(async()=>{
    const res=await fetch("/api/auction?sessionId="+sessionId);
    if(!res.ok)return;
    const json=await res.json();
    const s=json.session;
    if(s&&s.timer_started_at!=null)s.timer_started_at=Number(s.timer_started_at);
    const nc=(json.players as AuctionPlayer[]).filter(p=>p.is_captain===0);
    // timer_started 1→0: 낙찰 완료
    if(prevTimerStartedRef.current===1&&s?.timer_started===0&&!nextingRef.current&&!awardedRef.current){
      const prevPlayer=nc.find(p=>p.id===prevPlayerIdRef.current)??null;
      const allBids=json.bids as AuctionBid[];
      const tb=allBids.filter(b=>b.player_id===(prevPlayer?.id??-1)).reduce<AuctionBid|null>((top,b)=>(!top||b.points>top.points)?b:top,null);
      if(tb&&prevPlayer){setFrozenPlayer(prevPlayer);setAwardedTopBid(tb);setAwarded(true);}
    }
    // current_idx 증가 감지: 어드민이 다음 누름 → 팀장 화면 리셋
    const isCaptain=!!(myUserIdRef.current&&(json.players as AuctionPlayer[]).find(p=>p.is_captain===1&&p.user_id===myUserIdRef.current));
    if(isCaptain&&awardedRef.current&&prevCurrentIdxRef.current!==null&&s?.current_idx!==prevCurrentIdxRef.current){
      setAwarded(false);setAwardedTopBid(null);setFrozenPlayer(null);setAwardCd(null);prevTopRef.current=0;
      prevPlayerIdRef.current=nc.filter(p=>p.team_id===null)[0]?.id??null;
    }
    prevTimerStartedRef.current=s?.timer_started??null;
    prevCurrentIdxRef.current=s?.current_idx??null;
    setSession(s);setPlayers(json.players);setBids(json.bids);setServerNow(json.serverNow??null);
  },[sessionId]);
  useEffect(()=>{
    load();
    pollRef.current=setInterval(load,500);
    return()=>{if(pollRef.current)clearInterval(pollRef.current);};
  },[load]);
  useEffect(()=>{
    const newTop=topBid?.points??0;
    if(newTop>prevTopRef.current&&!awardingRef.current){prevTopRef.current=newTop;setAwardCd(null);}
  },[topBid?.points]);
  useEffect(()=>{
    const pid=currentPlayer?.id??null;
    if(pid!==prevPlayerIdRef.current&&!nextingRef.current&&!awardedRef.current){
      prevPlayerIdRef.current=pid;timerResetRef.current?.();
      setAwarded(false);setAwardedTopBid(null);setFrozenPlayer(null);setAwardCd(null);prevTopRef.current=0;
    }
  },[currentPlayer?.id]);
  function onTimerEnd(){if(sessionRef.current?.status==="running"){if(topBidRef.current)setAwardCd(1);else setAwarded(true);}}
  const handleAwardRef=useRef(handleAward);handleAwardRef.current=handleAward;
  useEffect(()=>{
    if(awardCd===null)return;
    if(awardCd<=0){if(isAdmin&&!awardingRef.current)handleAwardRef.current();return;}
    const t=setTimeout(()=>setAwardCd(prev=>(prev??1)-1),1000);
    return()=>clearTimeout(t);
  },[awardCd,isAdmin]);
  async function handleAward(){
    if(awardingRef.current)return;
    awardingRef.current=true;
    const wonBid=topBidRef.current;
    const frozen=currentPlayer;
    setFrozenPlayer(frozen);setAwarded(true);setAwardedTopBid(wonBid);
    await fetch("/api/auction",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"award",sessionId})});
    await load();
    setAwardCd(null);prevTopRef.current=0;timerResetRef.current?.();
    awardingRef.current=false;
  }
  async function handleNext(){
    nextingRef.current=true;setNexting(true);
    setAwarded(false);setAwardedTopBid(null);setFrozenPlayer(null);setAwardCd(null);prevTopRef.current=0;timerResetRef.current?.();
    if(!topBidRef.current){
      await fetch("/api/auction",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"award",sessionId})});
    }
    await fetch("/api/auction",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"next",sessionId})});
    const res=await fetch("/api/auction?sessionId="+sessionId);
    if(res.ok){
      const json=await res.json();
      const s=json.session;
      if(s&&s.timer_started_at!=null)s.timer_started_at=Number(s.timer_started_at);
      setSession(s);setPlayers(json.players);setBids(json.bids);setServerNow(json.serverNow??null);
      const nc=(json.players as AuctionPlayer[]).filter(p=>p.is_captain===0);
      prevPlayerIdRef.current=nc.filter(p=>p.team_id===null)[0]?.id??null;
    }
    nextingRef.current=false;setNexting(false);
  }
  async function handleBid(pts:number){
    if(!myCaptain)return;
    setBidLoading(true);setBidErr("");
    try{
      const res=await fetch("/api/auction",{method:"PATCH",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({action:"bid",sessionId,captainPlayerId:myCaptain.id,points:pts})});
      const json=await res.json();
      if(!res.ok){setBidErr(json.error||"입찰 실패");return;}
      load();
    }catch{setBidErr("네트워크 오류");}finally{setBidLoading(false);}
  }
  function getTeam(capId:number){return nonCaptains.filter(p=>p.team_id===capId);}
  function getUsed(capId:number){
    return nonCaptains
      .filter(p=>p.team_id===capId)
      .reduce((s,p)=>{
        const won=bids.filter(b=>b.player_id===p.id&&b.captain_id===capId).reduce((m,b)=>Math.max(m,b.points),0);
        return s+won;
      },0);
  }
  // 팀장 순서대로 팀 색상을 배정한다.
  function capColor(capId:number){const idx=captains.findIndex(c=>c.id===capId);return TEAM_COLORS[(idx<0?0:idx)%TEAM_COLORS.length];}
  async function patchAction(action:"start"|"reset"|"timer_start"){
    await fetch("/api/auction",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({action,sessionId})});
    load();
  }
  const isDone=session?.status==="done";
  const isRunning=session?.status==="running";
  const isWaiting=session?.status==="waiting";
  const remaining=nonCaptains.filter(p=>p.team_id===null).sort((a,b)=>a.sort_order-b.sort_order);
  const soldCount=nonCaptains.filter(p=>p.team_id!==null).length;
  const timer=<AuctionTimer onEnd={onTimerEnd} resetRef={timerResetRef} startedAt={nexting?null:timerStartedAt} serverNow={serverNow}/>;

  // 내 팀장 기준 입찰 가능 여부 계산
  const cpLine=currentPlayer?.roster_line??null;
  const myLineBlocked=!!myCaptain&&!!cpLine&&(myCaptain.roster_line===cpLine||getTeam(myCaptain.id).some(p=>p.roster_line===cpLine));
  const myCurrentBid=myCaptain&&currentPlayer?bids.filter(b=>b.player_id===currentPlayer.id&&b.captain_id===myCaptain.id).reduce((m,b)=>Math.max(m,b.points),0):0;
  const myLeft=myCaptain?myCaptain.points-getUsed(myCaptain.id):0;

  return(
    <div className={"auc-room"+(isAdmin?" with-queue":"")}>
      {/* ---------- 중앙: 현재 경매 ---------- */}
      <section className="auc-stage ui-card">
        {isWaiting&&(
          <div className="auc-stage-state">
            <div className="auc-stage-title">경매 대기 중</div>
            {isAdmin&&!myCaptain
              ?<button className="btn-primary auc-big-btn" onClick={()=>patchAction("start")}>경매 시작</button>
              :<p className="auc-stage-sub">운영진이 경매를 시작할 때까지 기다려 주세요.</p>}
          </div>
        )}
        {isDone&&(
          <div className="auc-stage-state">
            <div className="auc-stage-title done">경매 완료!</div>
            <p className="auc-stage-sub">모든 선수의 팀이 정해졌어요.</p>
            {isAdmin&&<button className="btn-secondary" onClick={()=>patchAction("reset")}>재경매</button>}
          </div>
        )}
        {isRunning&&!currentPlayer&&!activePlayer&&<div className="auc-stage-state"><p className="auc-stage-sub">모든 선수 경매 완료</p></div>}
        {isRunning&&activePlayer&&(
          <>
            <div className="auc-stage-top">
              <span className="ui-badge blue">진행중</span>
              <span className="auc-progress">{soldCount+1} / {nonCaptains.length}번째 선수</span>
            </div>

            <div className="auc-player">
              <div className="auc-player-name">{activePlayer.nickname}</div>
              <div className="auc-player-meta">
                {activePlayer.roster_line&&<span className="auc-player-line"><LineIcon line={activePlayer.roster_line} size={22}/>{LINE_LABEL[activePlayer.roster_line]??activePlayer.roster_line}</span>}
                <TierText tier={activePlayer.solo_tier} rank={activePlayer.solo_rank}/>
              </div>
              {(activePlayer.champ1||activePlayer.champ2||activePlayer.champ3)&&(
                <div className="auc-player-champs" title={champRevealed?undefined:"낙찰되면 공개돼요"}>
                  {([activePlayer.champ1,activePlayer.champ2,activePlayer.champ3] as (string|null)[]).map((c,i)=>(
                    <ChampImg key={i} name={c} size={72} hidden={!!c&&!champRevealed}/>
                  ))}
                </div>
              )}
            </div>

            {timer}

            {awardCd!==null&&awardCd>0&&timerStartedAt===null&&!awarded&&topBid&&(
              <div className="auc-notice warn">{topBid.captain_name} 낙찰 확정 중…</div>
            )}
            {!currentPlayer&&<div className="auc-notice">모든 선수 경매 완료</div>}
            {awarded&&topBid&&(
              <div className="auc-notice win" style={teamVar(capColor(topBid.captain_id))}>🏆 {topBid.captain_name} 낙찰 · {topBid.points}pt</div>
            )}

            <div className="auc-bids">
              <div className="auc-label">입찰 현황</div>
              {currentBids.length===0&&<div className="auc-bids-empty">아직 입찰 없음</div>}
              {[...currentBids].sort((a,b)=>b.points-a.points).slice(0,5).map(b=>{
                const isTop=b.id===topBid?.id;
                return(
                  <div key={b.id} className={"auc-bid-row"+(isTop?" top":"")} style={teamVar(capColor(b.captain_id))}>
                    <span>{isTop&&<span className="auc-crown">최고</span>}{b.captain_name}</span>
                    <strong>{b.points}pt</strong>
                  </div>
                );
              })}
            </div>

            {myCaptain&&(
              <div className="auc-bid-panel">
                {myLineBlocked&&<div className="auc-notice danger">이미 {LINE_LABEL[cpLine!]??cpLine} 라인을 보유 중이라 입찰할 수 없어요.</div>}
                <div className="auc-bid-btns">
                  {BID_STEPS.map((n,i)=>{
                    const next=(topBid?.points??0)+n;
                    const remain=myCaptain.points-getUsed(myCaptain.id)-myCurrentBid;
                    const dis=bidLoading||myLineBlocked||next>remain+myCurrentBid||awarded||!timerStartedAt;
                    return(
                      <button key={n} className={"auc-bid-btn t"+i} onClick={()=>handleBid(next)} disabled={dis}>
                        <small>+{n}pt</small>
                        <span>{next}pt</span>
                      </button>
                    );
                  })}
                </div>
                {bidErr&&<div className="auc-bid-err">{bidErr}</div>}
                <div className="auc-bid-info">
                  내 잔여 <strong>{myLeft}pt</strong>
                  {topBid&&<> · 현재 최고 <strong>{topBid.points}pt</strong> ({topBid.captain_name})</>}
                </div>
              </div>
            )}

            {isAdmin&&!myCaptain&&(!timerStartedAt&&!awarded||awarded)&&(
              <div className="auc-admin-ctrl">
                {!timerStartedAt&&!awarded&&<button className="btn-primary" onClick={()=>patchAction("timer_start")}>▶ 입찰 시작</button>}
                {awarded&&<button className="btn-primary auc-next-btn" onClick={handleNext}>다음 선수 →</button>}
              </div>
            )}
          </>
        )}
      </section>

      {/* ---------- 왼쪽: 팀 현황 ---------- */}
      <section className="auc-teams">
        {captains.map(cap=>{
          const team=getTeam(cap.id);const used=getUsed(cap.id);const left=cap.points-used;const isMe=myCaptain?.id===cap.id;
          return(
            <div key={cap.id} className={"auc-team"+(isMe?" me":"")} style={teamVar(capColor(cap.id))}>
              <div className="auc-team-head">
                <span className="auc-team-name">{cap.nickname}{isMe&&<span className="auc-me">나</span>}</span>
                <span className={"auc-team-pt"+(left<200?" low":"")}>{left}<small>pt</small></span>
              </div>
              <div className="auc-slots">
                {LINES.map(line=>{
                  const isCaptainLine=cap.roster_line===line;
                  const member=isCaptainLine?cap:team.find(pl=>pl.roster_line===line)??null;
                  const wonPts=member&&!isCaptainLine?bids.filter(b=>b.player_id===member.id&&b.captain_id===cap.id).reduce((m,b)=>Math.max(m,b.points),0):null;
                  return(
                    <div key={line} className={"auc-slot"+(member?" filled":"")}>
                      <LineIcon line={line} size={18} dim={!member}/>
                      {member
                        ?<span className="auc-slot-name">{member.nickname}{isCaptainLine?<em className="cap">팀장</em>:wonPts!==null&&<em>{wonPts}pt</em>}</span>
                        :<span className="auc-slot-empty">{LINE_LABEL[line]}</span>}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </section>

      {/* ---------- 오른쪽: 경매 순서 (운영진) ---------- */}
      {isAdmin&&(
        <aside className="auc-queue ui-card">
          <div className="auc-label">경매 순서 <em>{remaining.length}명 남음</em></div>
          <ol className="auc-queue-list">
            {remaining.map((pl,i)=>(
              <li key={pl.id} className={currentPlayer?.id===pl.id?"current":""}>
                <span className="idx">{i+1}</span>{pl.nickname}<LineIcon line={pl.roster_line} size={14} dim/>
              </li>
            ))}
            {remaining.length===0&&<li className="none">없음</li>}
          </ol>
        </aside>
      )}
    </div>
  );
}
