"use client";

import { useEffect, useRef, useState } from "react";
import * as XLSX from "xlsx";
import { useAuth } from "../components/AuthProvider";
import { mmrToScrimTier, SCRIM_TIERS, SCRIM_TIER_KO } from "../../lib/scrim";

const SCRIM_TIER_INITIAL: Record<string, number> = {
  BRONZE: 0, SILVER: 200, GOLD: 400, PLATINUM: 600, EMERALD: 800, DIAMOND: 1000, MASTER: 1200,
};

// 연동된 게임 계정 정보 (본계정 여부, 게임 수, 마지막 동기화 시각 포함)
interface Account {
  id: number;
  gameName: string;
  tagLine: string;
  isMain: boolean;
  hasPuuid: boolean;
  gamesTotal: number; 
  games2w: number;
  lastSyncedAt: string | null;
}
// 솔로랭크 티어 정보 (티어명, 디비전, LP)
interface TierInfo {
  tier: string;
  rank: string;
  lp: number;
}
// 클랜원 전체 정보 (계정, 티어, 활동 포인트, 경고, 수습 로그 포함)
interface Member {
  id: number;
  nickname: string;    
  displayName: string; 
  birthDate: string | null;
  birthYear: number | null;
  gender: string | null;
  mainLine: string | null;
  subLine: string | null;
  position: string;
  status: string;
  statusNote: string | null;
  accounts: Account[];
  gamesTotal: number;
  games2w: number;
  aramGames2w: number;
  normalGames2w: number;
  tier: TierInfo | null;
  totalPoints: number;
  warningCount: number;
  rookiePartyCount: number;
  createdAt: string | null;
  promotedAt: string | null;
  rookieSessionLogs?: { id?: number; games: number; partyCount: number; comment: string; date: string; startAt: string; mode: string; members: string[] }[];
  recentLogs?: { id?: number; type: string; games: number; comment: string; date: string; startAt: string; mode: string; members: string[] }[];
}


// 티어 영문명 → 한국어 변환 맵
const TIER_KO: Record<string, string> = {
  IRON: "아이언",
  BRONZE: "브론즈",
  SILVER: "실버",
  GOLD: "골드",
  PLATINUM: "플래티넘",
  EMERALD: "에메랄드",
  DIAMOND: "다이아몬드",
  MASTER: "마스터",
  GRANDMASTER: "그랜드마스터",
  CHALLENGER: "챌린저",
};
const NO_DIVISION = ["MASTER", "GRANDMASTER", "CHALLENGER"];
// 티어 표시 문자열 생성 (마스터 이상은 LP 표시, 나머지는 디비전 숫자)
function tierLabel(t: TierInfo): string {
  const ko = TIER_KO[t.tier] ?? t.tier;
  if (NO_DIVISION.includes(t.tier)) {
    return t.tier === "MASTER" ? `${ko} ${t.lp}LP` : ko;
  }
  const div = { I: "1", II: "2", III: "3", IV: "4" }[t.rank] ?? t.rank;
  return `${ko} ${div}`;
}

// 티어 엠블럼 이미지 경로 반환 (/public/tiers/ 폴더 기준)
function tierEmblemUrl(tier: string) { return `/tiers/emblem-${tier.toLowerCase()}.png`; }


// 활동 포인트 구간별 활동 티어 정의 (C/M/D/E/P/G/S/B)
const ACTIVITY_TIERS = [
  { min: 3300, label: "C", color: "#d9a441" },   // Challenger
  { min: 2800, label: "M", color: "#9d4dc3" },   // Master
  { min: 2300, label: "D", color: "#4f7bd0" },   // Diamond
  { min: 1800, label: "E", color: "#2f9e6b" },   // Emerald
  { min: 1300, label: "P", color: "#3aa6a0" },   // Platinum
  { min: 800,  label: "G", color: "#cf9b41" },   // Gold
  { min: 300,  label: "S", color: "#7e93a3" },   // Silver
  { min: 0,    label: "B", color: "#8c5230" },   // Bronze
] as const;

// 포인트로 활동 티어 계산 (구간 중 첫 번째 매칭 반환)
function activityTier(points: number) {
  return ACTIVITY_TIERS.find((t) => points >= t.min) ?? null;
}

// 활동 시간 "MM.DD HH:MM"(날짜 포함). 오늘이면 "방금 활동".
function syncedTime(iso: string | null) {
  if (!iso) return "미동기화";
  const d = new Date(iso);
  const mo = String(d.getMonth() + 1).padStart(2, "0");
  const da = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${mo}.${da} ${hh}:${mm}`;
}

// 페이지당 표시 인원 선택지
const PAGE_SIZES = [10, 20]; 
// 라인 필터 키 목록
const LINE_KEYS = ["TOP", "JG", "MID", "ADC", "SUP", "ARAM"] as const; 

// 로그인 계정 정보 (관리자 탭에서 사용)
interface LinkedUser {
  id: number;
  username: string;
  nickname: string;
  role: string;
  scrimOnly: boolean;
  showRoster: boolean;
  status: string;
  createdAt?: string;
}

// 클랜원 목록 페이지 메인 컴포넌트
export default function UserInfoPage() {
  const { user, isAdmin, loading: authLoading, openAuthModal } = useAuth();
  const editModalMouseDownInside = useRef(false);
  const [members, setMembers] = useState<Member[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

// ── 로그인 계정 관련 state ──
  
  const [users, setUsers] = useState<LinkedUser[]>([]);
  const [linkMsg, setLinkMsg] = useState("");

// 로그인 계정 목록 불러오기 (관리자 전용)
  async function loadUsers() {
    try {
      const res = await fetch("/api/userinfo/link");
      const json = await res.json();
      if (res.ok) setUsers(json.users);
    } catch { /* 무시 */ }
  }

  
// 선택한 유저의 비밀번호를 1234로 초기화
  async function resetPassword(userId: number, username: string) {
    if (!confirm(`"${username}" 의 비밀번호를 1234로 초기화할까요?`)) return;
    setLinkMsg("");
    try {
      const res = await fetch("/api/userinfo/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      const json = await res.json();
      if (!res.ok) { setLinkMsg(json.error || "초기화 실패"); return; }
      alert(`"${username}" 의 비밀번호가 1234로 초기화되었습니다.`);
    } catch { setLinkMsg("네트워크 오류"); }
  }

  
// 대기 중인 계정 승인 처리
  async function approveUser(userId: number, username: string) {
    if (!confirm(`"${username}" 계정을 승인하시겠습니까?`)) return;
    setLinkMsg("");
    try {
      const res = await fetch("/api/userinfo/link", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, approve: true }),
      });
      const json = await res.json();
      if (!res.ok) { setLinkMsg(json.error || "승인 실패"); return; }
      loadUsers();
    } catch { setLinkMsg("네트워크 오류"); }
  }

// 유저 권한(role) 변경
  async function changeRole(userId: number, role: string) {
    const res = await fetch("/api/userinfo/link", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, role }),
    });
    const json = await res.json();
    if (!res.ok) { setLinkMsg(json.error || "역할 변경 실패"); return; }
    loadUsers();
  }
// 로그인 계정 삭제 (연동된 클랜원 정보도 함께 삭제)
  async function deleteUser(userId: number, username: string) {
    if (!confirm(`"${username}" 계정을 삭제하시겠습니까? 연동된 클랜원 정보도 함께 삭제됩니다.`)) return;
    setLinkMsg("");
    try {
      const res = await fetch(`/api/userinfo/link?id=${userId}`, { method: "DELETE" });
      const json = await res.json();
      if (!res.ok) { setLinkMsg(json.error || "삭제 실패"); return; }
      loadUsers();
    } catch { setLinkMsg("네트워크 오류"); }
  }

// ── 검색 / 필터 / 정렬 state ──
  
  const [searchQuery, setSearchQuery] = useState("");

  
  const [lineFilter, setLineFilter] = useState("");

  
  const [showInactive, setShowInactive] = useState(false);

  
  const [specialFilter, setSpecialFilter] = useState<"" | "rookie" | "leave" | "warn" | "withdraw">("");
  const [sortBy, setSortBy] = useState<"birth" | "activityTier">("birth");

// ── 페이지네이션 state ──
  // 초기화
  const [pageSize, setPageSize] = useState(10);
  const [page, setPage] = useState(0); 

// ── 클랜원 추가 모달 state ──
  
  const [memberModal, setMemberModal] = useState(false);
  const [memberInput, setMemberInput] = useState("");
  const [memberModalErr, setMemberModalErr] = useState("");
  const [memberModalBusy, setMemberModalBusy] = useState(false);
  
// ── 엑셀 업로드 state ──
  
  const [uploading, setUploading] = useState(false);
  const [uploadMsg, setUploadMsg] = useState("");

// ── 티어 동기화 state ──
  const [syncingId, setSyncingId] = useState<number | null>(null);
  const [syncMsg, setSyncMsg] = useState("");

// ── 계정 추가 모달 state ──
  
  const [accModal, setAccModal] = useState<{ memberId: number; nickname: string } | null>(null);
  const [accInput, setAccInput] = useState(""); // "닉네임#태그" 형식
  const [accIsMain, setAccIsMain] = useState(false);
  const [accModalErr, setAccModalErr] = useState("");
  const [accModalBusy, setAccModalBusy] = useState(false);

// ── 클랜원 수정 모달 state ──
  
  const [editModal, setEditModal] = useState<Member | null>(null);
  const [editForm, setEditForm] = useState<{
    birthYear: string;
    birthMD: string;
    gender: string;
    mainLine: string;
    subLine: string;
    position: string;
    status: string;
    statusNote: string;
    scrimTier: string;
    scrimMmr: number;
  }>({
    birthYear: "",
    birthMD: "",
    gender: "",
    mainLine: "",
    subLine: "",
    position: "클랜원",
    status: "active",
    statusNote: "",
    scrimTier: "BRONZE",
    scrimMmr: 0,
  });

  const [achievePickerId, setAchievePickerId] = useState<number | null>(null);
  const [achieveDate, setAchieveDate] = useState("");

// ── 탈퇴 모달 state ──
  const [withdrawModal, setWithdrawModal] = useState<{ member: Member } | null>(null);
  const [withdrawReason, setWithdrawReason] = useState("");
  const [withdrawReasonModal, setWithdrawReasonModal] = useState<{ nickname: string; reason: string; memberId: number; withdrewAt: string } | null>(null);
  const [withdrawReasonEdit, setWithdrawReasonEdit] = useState("");

  async function submitWithdraw() {
    if (!withdrawModal) return;
    const m = withdrawModal.member;
    const res = await fetch("/api/userinfo/member", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: m.id, position: m.position, status: "withdraw", birthYear: m.birthYear, birthDate: m.birthDate, gender: m.gender, mainLine: m.mainLine, subLine: m.subLine, statusNote: withdrawReason || null }),
    });
    if (res.ok) { setWithdrawModal(null); setWithdrawReason(""); loadMembers(); }
    else alert("탈퇴 처리 실패");
  }

// ── 블랙리스트 모달 state ──
  const [blacklistModal, setBlacklistModal] = useState<{ memberId: number; nickname: string; entries: any[] } | null>(null);
  const [blacklistForm, setBlacklistForm] = useState({ reason: "", addedAt: new Date(Date.now() + 9*60*60*1000).toISOString().slice(0, 10) });

  async function openBlacklistModal(m: Member) {
    const res = await fetch(`/api/userinfo/blacklist?memberId=${m.id}`);
    const json = await res.json();
    setBlacklistModal({ memberId: m.id, nickname: m.nickname, entries: res.ok ? json.blacklist : [] });
  }

// ── 경고 관리 모달 state ──
  
  const [warnModal, setWarnModal] = useState<{ memberId: number; nickname: string } | null>(null);
  const [warnings, setWarnings] = useState<any[]>([]);
  const [warnForm, setWarnForm] = useState({ type: "운영 방침 위반", reason: "", warnedAt: new Date(Date.now() + 9*60*60*1000).toISOString().slice(0, 10) });
  const [warnLoading, setWarnLoading] = useState(false);
  const [editingWarnId, setEditingWarnId] = useState<number | null>(null);
  const [editingWarnForm, setEditingWarnForm] = useState({ type: "운영 방침 위반", reason: "", warnedAt: "" });
  const [editingBlackId, setEditingBlackId] = useState<number | null>(null);
  const [editingBlackForm, setEditingBlackForm] = useState({ reason: "", addedAt: "" });

// 경고 모달 열기 + 해당 클랜원의 경고 내역 불러오기
  async function openWarnModal(m: Member) {
    setWarnModal({ memberId: m.id, nickname: m.nickname });
    setWarnLoading(true);
    try {
      const res = await fetch(`/api/userinfo/warning?memberId=${m.id}`);
      const json = await res.json();
      if (res.ok) setWarnings(json.warnings);
    } catch {}
    finally { setWarnLoading(false); }
  }

// 경고 추가 후 목록 갱신
  async function addWarning() {
    if (!warnModal) return;
    const res = await fetch("/api/userinfo/warning", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ memberId: warnModal.memberId, ...warnForm }),
    });
    if (res.ok) {
      setWarnForm({ type: "운영 방침 위반", reason: "", warnedAt: new Date(Date.now() + 9*60*60*1000).toISOString().slice(0, 10) });
      const r2 = await fetch(`/api/userinfo/warning?memberId=${warnModal.memberId}`);
      const j2 = await r2.json();
      if (r2.ok) setWarnings(j2.warnings);
      loadMembers();
    }
  }

// 경고 수정 저장
  async function saveWarning(id: number, memberId: number) {
    await fetch("/api/userinfo/warning", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...editingWarnForm }),
    });
    setEditingWarnId(null);
    const r = await fetch(`/api/userinfo/warning?memberId=${memberId}`);
    const j = await r.json();
    if (r.ok) setWarnings(j.warnings);
  }

// 경고 삭제 후 목록 갱신
  async function deleteWarning(id: number) {
    const target = warnModal?.nickname ?? editModal?.nickname ?? "";
    if (!confirm(`${target ? `"${target}"의 ` : ""}경고를 삭제하시겠습니까?`)) return;
    await fetch(`/api/userinfo/warning?id=${id}`, { method: "DELETE" });
    const targetId = warnModal?.memberId ?? editModal?.id;
    if (targetId) {
      const r2 = await fetch(`/api/userinfo/warning?memberId=${targetId}`);
      const j2 = await r2.json();
      if (r2.ok) setWarnings(j2.warnings);
      loadMembers();
    }
  }

// ── 필터링 / 정렬 로직 ──
  
// 검색어, 라인 필터, 특수 필터(수습/외출/판수미달) 적용
  const filteredMembers = members.filter((m) => {
    
    if (showInactive && m.position === "수습") return false;
    if (showInactive && (m.status === "leave" || m.status === "withdraw" || m.status === "black")) return false;
    if (showInactive && (m.position === "운영진" || m.position === "부운영진")) return false;
    const fourDaysMs = 4 * 24 * 60 * 60 * 1000;
    if (showInactive && m.promotedAt && Date.now() - new Date(m.promotedAt).getTime() < fourDaysMs) return false;
    if (showInactive) {
      const last = (m as any).lastAchievedAt;
      if (!last) return false;
      const [y, mo, d] = last.split("-").map(Number);
      const lastDate = new Date(y, mo - 1, d);
      const today = new Date(); today.setHours(0,0,0,0);
      const daysSince = Math.floor((today.getTime() - lastDate.getTime()) / (24 * 60 * 60 * 1000));
      if (daysSince < 10) return false;
    }
    
    if (specialFilter === "rookie" && m.position !== "수습") return false;
    if (specialFilter === "leave" && m.status !== "leave") return false;
    if (specialFilter === "warn" && m.warningCount === 0) return false;
    if (specialFilter === "withdraw") return m.status === "withdraw" || m.status === "black";
    if (m.status === "withdraw" || m.status === "black") return false;
    
    if (lineFilter && m.mainLine !== lineFilter) return false;

    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    
    if (m.nickname.toLowerCase().includes(q)) return true;
    if (m.birthDate && m.birthDate.slice(0, 4).includes(q)) return true;
    return m.accounts.some(
      (a) =>
        a.gameName.toLowerCase().includes(q) ||
        a.tagLine.toLowerCase().includes(q)
    );
  });
// 정렬: 수습이면 가입일순 / 활동티어면 포인트순 / 기본은 직책→출생연도→이름순
  const TIER_ORDER = ["CHALLENGER","GRANDMASTER","MASTER","DIAMOND","EMERALD","PLATINUM","GOLD","SILVER","BRONZE","IRON"];
  const positionOrder = (p: string) => p === "운영진" ? 0 : p === "부운영진" ? 1 : 2;
  const sortedMembers = specialFilter === "rookie"
    ? [...filteredMembers].sort((a, b) => (a.createdAt ?? "").localeCompare(b.createdAt ?? ""))
    : sortBy === "activityTier"
    ? [...filteredMembers].sort((a, b) => b.totalPoints - a.totalPoints || a.nickname.localeCompare(b.nickname, "ko"))
    : [...filteredMembers].sort((a, b) => {
        const po = positionOrder(a.position) - positionOrder(b.position);
        if (po !== 0) return po;
        const ay = a.birthYear ?? 9999;
        const by = b.birthYear ?? 9999;
        if (ay !== by) return ay - by;
        return a.nickname.localeCompare(b.nickname, "ko");
      });
// 페이지네이션 계산
  const totalPages = Math.max(1, Math.ceil(filteredMembers.length / pageSize));
  const safePage = Math.min(page, totalPages - 1);
  const pagedMembers = sortedMembers.slice(
    safePage * pageSize,
    safePage * pageSize + pageSize
  );

// 수정 모달 열기: 클랜원 데이터로 폼 초기화 + 경고 내역 로드
  async function openEditModal(m: Member) {
    setEditModal(m);
    setWarnings([]);
    try {
      const res = await fetch(`/api/userinfo/warning?memberId=${m.id}`);
      const json = await res.json();
      if (res.ok) setWarnings(json.warnings);
    } catch {}

    setEditForm({
      birthYear: m.birthYear ? String(m.birthYear) : "",
      birthMD: m.birthDate ? m.birthDate.slice(5) : "", 
      gender: m.gender ?? "",
      mainLine: m.mainLine || "",
      subLine: m.subLine || "",
      position: m.position || "클랜원",
      status: m.status || "active",
      statusNote: m.statusNote || "",
      scrimTier: mmrToScrimTier((m as any).scrimMmr ?? 0),
      scrimMmr: (m as any).scrimMmr ?? 0,
    });
  }

// 수정 내용 저장 (PUT /api/userinfo/member)
  async function saveEdit() {
    if (!editModal) return;
    try {
      const res = await fetch("/api/userinfo/member", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: editModal.id,
          birthYear: editForm.birthYear ? Number(editForm.birthYear) : null,
          birthDate: editForm.birthYear && editForm.birthMD.match(/^\d{2}-\d{2}$/) ? `${editForm.birthYear}-${editForm.birthMD}` : null,
          gender: editForm.gender || null,
          mainLine: editForm.mainLine || null,
          subLine: editForm.subLine || null,
          position: editForm.position || "클랜원",
          status: editForm.status || "active",
          statusNote: editForm.statusNote || null,
          scrimMmr: editForm.scrimMmr,
        }),
      });
      const json = await res.json();
      if (!res.ok) { alert(json.error || "저장 실패"); return; }
      setEditModal(null);
      loadMembers();
    } catch { alert("네트워크 오류"); }
  }

// 클랜원 목록 불러오기 (GET /api/userinfo)
  async function loadMembers() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/userinfo");
      const json = await res.json();
      if (!res.ok) setError(json.error || "불러오기 실패");
      else {
        
        setMembers(json.members);
      }
    } catch {
      setError("네트워크 오류");
    } finally {
      setLoading(false);
    }
  }


// 로그인 상태 변경 시 클랜원 목록 재로드
  
  useEffect(() => {
    if (authLoading) return;
    if (!user) { setLoading(false); setMembers([]); return; }
    loadMembers();
  }, [user, authLoading]);

// 관리자 로그인 시 로그인 계정 목록 로드
  useEffect(() => {
    if (isAdmin) loadUsers();
  }, [isAdmin]);

// 클랜원 추가 모달 제출: gameName#tagLine 파싱 후 POST
  async function submitMemberModal() {
    const raw = memberInput.trim();
    const hashIdx = raw.lastIndexOf("#");
    if (hashIdx < 1 || hashIdx === raw.length - 1) {
      setMemberModalErr("닉네임#태그 형식으로 입력하세요. (예: 소환사#KR1)");
      return;
    }
    const gameName = raw.slice(0, hashIdx).trim();
    const tagLine = raw.slice(hashIdx + 1).trim();
    setMemberModalBusy(true);
    setMemberModalErr("");
    try {
      const res = await fetch("/api/userinfo/member", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ gameName, tagLine }),
      });
      const json = await res.json();
      if (!res.ok) { setMemberModalErr(json.error || "추가 실패"); return; }
      setMemberModal(false);
      setMemberInput("");
      loadMembers();
    } catch { setMemberModalErr("네트워크 오류"); }
    finally { setMemberModalBusy(false); }
  }

  async function addMember(e: React.FormEvent) { e.preventDefault(); }

// 계정 추가 모달 제출 (독립 모달에서 사용)
  async function submitAccModal() {
    if (!accModal) return;
    const raw = accInput.trim();
    const hashIdx = raw.lastIndexOf("#");
    if (hashIdx < 1 || hashIdx === raw.length - 1) {
      setAccModalErr("닉네임#태그 형식으로 입력하세요. (예: 소환사#KR1)");
      return;
    }
    const gameName = raw.slice(0, hashIdx).trim();
    const tagLine = raw.slice(hashIdx + 1).trim();
    if (!gameName || !tagLine) {
      setAccModalErr("닉네임 또는 태그라인을 입력하세요.");
      return;
    }
    setAccModalBusy(true);
    setAccModalErr("");
    try {
      const res = await fetch("/api/userinfo/account", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ memberId: accModal.memberId, gameName, tagLine, isMain: accIsMain }),
      });
      const json = await res.json();
      if (!res.ok) { setAccModalErr(json.error || "계정 추가 실패"); return; }
      setAccModal(null);
      setAccInput("");
      setAccIsMain(false);
      loadMembers();
    } catch { setAccModalErr("네트워크 오류"); }
    finally { setAccModalBusy(false); }
  }

// 수정 모달 내 계정 추가 제출 (수정 모달에서 직접 계정 추가)
  async function submitAccFromEditModal() {
    if (!editModal) return;
    const raw = accInput.trim();
    const hashIdx = raw.lastIndexOf("#");
    if (hashIdx < 1 || hashIdx === raw.length - 1) {
      setAccModalErr("닉네임#태그 형식으로 입력하세요. (예: 소환사#KR1)");
      return;
    }
    const gameName = raw.slice(0, hashIdx).trim();
    const tagLine = raw.slice(hashIdx + 1).trim();
    setAccModalBusy(true);
    setAccModalErr("");
    try {
      const res = await fetch("/api/userinfo/account", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ memberId: editModal.id, gameName, tagLine, isMain: accIsMain }),
      });
      const json = await res.json();
      if (!res.ok) { setAccModalErr(json.error || "계정 추가 실패"); return; }
      setAccInput("");
      setAccIsMain(false);
      const updated = await fetch("/api/userinfo").then((r) => r.json());
      const fresh = (updated.members as Member[]).find((m) => m.id === editModal.id);
      if (fresh) setEditModal(fresh);
      loadMembers();
    } catch { setAccModalErr("네트워크 오류"); }
    finally { setAccModalBusy(false); }
  }

// 솔로랭크 티어 동기화 (단일 또는 전체)
  async function syncTier(memberId: number | null) {
    setSyncingId(memberId ?? 0);
    setSyncMsg("");
    try {
      const res = await fetch("/api/userinfo/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(memberId ? { memberId } : {}),
      });
      const json = await res.json();
      if (!res.ok) { setSyncMsg(json.error || "동기화 실패"); return; }
      await loadMembers();
      if (memberId) {
        setMembers((prev) => {
          const fresh = prev.find((m) => m.id === memberId);
          if (fresh) setEditModal(fresh);
          return prev;
        });
      }
    } catch { setSyncMsg("네트워크 오류"); }
    finally { setSyncingId(null); }
  }

// 클랜원 또는 계정 삭제
  async function remove(kind: "member" | "account", id: number, label?: string) {
    if (!confirm(label ? `"${label}"을(를) 삭제하시겠습니까?` : "삭제하시겠습니까?")) return;
    try {
      const res = await fetch("/api/userinfo/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, id }),
      });
      if (!res.ok) {
        const json = await res.json();
        alert(json.error || "삭제 실패");
        return;
      }
      loadMembers();
    } catch (err) {
      console.error("[remove] 네트워크 오류:", err);
      alert("네트워크 오류");
    }
  }


// ── 탭 state (클랜원 / 로그인계정 / 파티내역) ──
  const [tab, setTab] = useState<"members" | "accounts" | "party-history">("members");

// 관리자는 기본 탭을 로그인계정 탭으로 설정
  useEffect(() => {
    if (user?.role === "admin") setTab("accounts");
  }, [user?.role]);

// ── 파티 내역 state ──
  
  const [historyData, setHistoryData] = useState<{
    parties: { id:number; mode:string; note:string|null; status:string; startAt:string|null; endedBy:string|null; participants:string[]; pastParticipants:string[] }[];
  } | null>(null);
  const [historyLoading, setHistoryLoading] = useState(false);

// 펑한 파티 내역 불러오기
  async function loadHistory() {
    setHistoryLoading(true);
    try {
      const res = await fetch(`/api/party/history`);
      const json = await res.json();
      if (res.ok) setHistoryData(json);
    } catch {}
    finally { setHistoryLoading(false); }
  }

  useEffect(() => {
    if (isAdmin && tab === "party-history") loadHistory();
  }, [isAdmin, tab]);

 
  const [rookieLogModal, setRookieLogModal] = useState<{ memberId: number; nickname: string; logs: { id?: number; games: number; partyCount: number; comment: string; date: string; startAt: string; mode: string; members: string[] }[] } | null>(null);
  const [inactiveLogModal, setInactiveLogModal] = useState<{ memberId: number; nickname: string; logs: { id?: number; type: string; games: number; comment: string; date: string; startAt: string; mode: string; members: string[] }[] } | null>(null);
  const [rookieEventForm, setRookieEventForm] = useState("");
  const [rookieEventOpen, setRookieEventOpen] = useState(false);
  const [rookieEventBusy, setRookieEventBusy] = useState(false);
  const [rookieEventErr, setRookieEventErr] = useState("");

// ESC 키로 모달 닫기
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key !== "Escape") return;
      if (withdrawReasonModal) { setWithdrawReasonModal(null); return; }
      if (withdrawModal) { setWithdrawModal(null); setWithdrawReason(""); return; }
      if (blacklistModal) { setBlacklistModal(null); return; }
      if (warnModal) { setWarnModal(null); return; }
      if (editModal) { setEditModal(null); return; }
      if (rookieLogModal) { setRookieLogModal(null); setRookieEventForm(""); setRookieEventOpen(false); setRookieEventErr(""); return; }
      if (inactiveLogModal) { setInactiveLogModal(null); return; }
      if (accModal) { setAccModal(null); return; }
      if (memberModal) { setMemberModal(false); return; }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [blacklistModal, warnModal, editModal, rookieLogModal, inactiveLogModal, accModal, memberModal]);

  async function submitRookieEvent() {
    if (!rookieLogModal) return;
    if (!rookieEventForm.trim()) { setRookieEventErr("사유를 입력하세요."); return; }
    setRookieEventBusy(true); setRookieEventErr("");
    try {
      const res = await fetch("/api/points", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ memberId: rookieLogModal.memberId, points: 0, type: "rookie_event", comment: rookieEventForm.trim() }),
      });
      const json = await res.json();
      if (!res.ok) { setRookieEventErr(json.error || "실패"); return; }
      setRookieEventForm(""); setRookieEventOpen(false);
      await loadMembers();
      setMembers((prev) => {
        const fresh = prev.find((m) => m.id === rookieLogModal.memberId);
        if (fresh) setRookieLogModal({ memberId: fresh.id, nickname: fresh.nickname, logs: fresh.rookieSessionLogs ?? [] });
        return prev;
      });
    } catch { setRookieEventErr("네트워크 오류"); }
    finally { setRookieEventBusy(false); }
  }


  const MODE_KO: Record<string,string> = { aram:"칼바람", normal:"일반협곡", flex:"자유랭크", solo:"솔로랭크", scrim:"내전", event:"이벤트" };

  
  function downloadExcel() {
    const rows = members.map((m) => ({
      "닉네임": m.nickname,
      "출생연도": m.birthYear || "",
      "생일(MM-DD)": m.birthDate ? m.birthDate.slice(5) : "",
      "직책": m.position,
      "주라인": m.mainLine || "",
      "부라인": m.subLine || "",
      "활동상태": m.status === "active" ? "활동" : "외출",
      "포인트": m.totalPoints,
      "본계정": (m.accounts.find((a) => a.isMain) || {}).gameName || "",
      "티어": m.tier ? tierLabel(m.tier) : "",
      "경고": m.warningCount,
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "클랜원");
    XLSX.writeFile(wb, "클랜원_목록.xlsx");
  }

  function downloadTemplate() {
    const template = [
      ["닉네임", "출생연도", "생일(MM-DD)", "주라인", "부라인", "계정1_이름", "계정1_태그", "계정1_본계정", "계정2_이름", "계정2_태그", "계정2_본계정"],
      ["홍길동", "1995", "03-15", "TOP", "JG", "HongGD", "KR1", "O", "HongSub", "KR2", ""],
      ["김철수", "1998", "", "SUP", "ADC", "KimCS", "1234", "O", "", "", ""],
      ["박영희", "2000", "11-02", "MID", "", "ParkYH", "ABCD", "O", "ParkAlt", "5678", ""],
    ];
    const ws = XLSX.utils.aoa_to_sheet(template);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "클랜원");
    XLSX.writeFile(wb, "클랜원_업로드_양식.xlsx");
  }

  
  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setUploadMsg("");

    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });

      // 첫 번째 계정을 메인으로 설정, 나머지 서브
      const members: Array<{
        nickname: string;
        birthYear?: number;
        birthDate?: string;
        mainLine?: string;
        subLine?: string;
        accounts: Array<{ gameName: string; tagLine: string; isMain: boolean }>;
      }> = [];

      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        if (!row || row.length === 0) continue;

        const nickname = String(row[0] || "").trim();
        if (!nickname) continue;

        const birthYear = row[1] ? Number(String(row[1]).trim()) || undefined : undefined;
        const birthMD = row[2] ? String(row[2]).trim() : "";
        const birthDate = birthYear && birthMD.match(/^\d{2}-\d{2}$/)
          ? `${birthYear}-${birthMD}`
          : undefined;
        const mainLine = String(row[3] || "").trim().toUpperCase() || undefined;
        const subLine = String(row[4] || "").trim().toUpperCase() || undefined;
        const accounts: Array<{ gameName: string; tagLine: string; isMain: boolean }> = [];

        
        for (let j = 5; j < row.length; j += 3) {
          const gameName = String(row[j] || "").trim();
          const tagLine = String(row[j + 1] || "").trim();
          const isMainStr = String(row[j + 2] || "").trim().toUpperCase();
          
          if (gameName && tagLine) {
            accounts.push({
              gameName,
              tagLine,
              isMain: isMainStr === "O" || isMainStr === "TRUE",
            });
          }
        }

        members.push({ nickname, birthYear, birthDate, mainLine, subLine, accounts });
      }

      if (members.length === 0) {
        setUploadMsg("유효한 데이터가 없습니다.");
        return;
      }

      
      const res = await fetch("/api/userinfo/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ members }),
      });

      const json = await res.json();
      if (!res.ok) {
        setUploadMsg(json.error || "업로드 실패");
      } else {
        let msg = `완료: 클랜원 ${json.addedMembers}명, 계정 ${json.addedAccounts}개 추가`;
        if (json.errors && json.errors.length > 0) {
          msg += ` / 오류 ${json.errors.length}건: ${json.errors.slice(0, 3).join(", ")}`;
        }
        setUploadMsg(msg);
        loadMembers();
      }
    } catch (err: any) {
      setUploadMsg(`오류: ${err.message}`);
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  }

  if (authLoading) return null;
  if (!user) {
    return (
      <div className="userinfo">
        <div className="party-login-notice">
          클랜원 목록을 보려면 로그인이 필요합니다.
          <button type="button" className="inline-login-btn" onClick={() => openAuthModal("login")}>로그인 / 회원가입</button>
        </div>
      </div>
    );
  }
  if (user.role === "captain" || user.scrimOnly) return (
    <div className="userinfo"><div className="party-login-notice">접근 권한이 없습니다.</div></div>
  );

  return (
    <div className="userinfo">
      {/* 달성일 갱신 팝업 */}
      {achievePickerId !== null && (
        <div className="modal-backdrop" onClick={() => { setAchievePickerId(null); setAchieveDate(""); }}>
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 300 }}>
            <div className="modal-head">
              <span>📅 달성일 갱신</span>
              <button className="modal-close" onClick={() => { setAchievePickerId(null); setAchieveDate(""); }}>×</button>
            </div>
            <input
              type="date"
              value={achieveDate}
              onChange={(e) => setAchieveDate(e.target.value)}
              autoFocus
              style={{ width: "100%", padding: "10px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 15, boxSizing: "border-box", marginBottom: 12 }}
            />
            <div style={{ display: "flex", gap: 8 }}>
              <button className="sync-btn" style={{ flex: 1 }} onClick={async () => {
                const res = await fetch("/api/userinfo/achieve", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ memberId: achievePickerId, achievedAt: achieveDate || undefined }),
                });
                if (res.ok) { setAchievePickerId(null); setAchieveDate(""); loadMembers(); }
                else alert("갱신 실패");
              }}>확인</button>
              <button className="cancel-btn" style={{ flex: 1 }} onClick={() => { setAchievePickerId(null); setAchieveDate(""); }}>취소</button>
            </div>
          </div>
        </div>
      )}
      {/* 탈퇴 사유 보기 모달 */}
      {withdrawReasonModal && (
        <div className="modal-backdrop">
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 360 }}>
            <div className="modal-head">
              <span>🚪 {withdrawReasonModal.nickname} 탈퇴 사유</span>
              <button className="modal-close" onClick={() => setWithdrawReasonModal(null)}>×</button>
            </div>
            <textarea value={withdrawReasonEdit} onChange={e => setWithdrawReasonEdit(e.target.value)} rows={3}
              style={{ width: "100%", padding: "8px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 14, resize: "vertical", boxSizing: "border-box" }} />
            <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
              <button className="sync-btn" style={{ flex: 1 }} onClick={async () => {
                await fetch("/api/userinfo/member", { method: "PUT", headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ id: withdrawReasonModal.memberId, status: "withdraw", statusNote: withdrawReasonEdit || null,
                    withdrewAt: withdrawReasonModal.withdrewAt }) });
                setWithdrawReasonModal(null); loadMembers();
              }}>저장</button>
              <button className="cancel-btn" style={{ flex: 1 }} onClick={() => setWithdrawReasonModal(null)}>취소</button>
            </div>
          </div>
        </div>
      )}
      {/* 탈퇴 모달 */}
      {withdrawModal && (
        <div className="modal-backdrop">
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 400 }}>
            <div className="modal-head">
              <span>🚪 {withdrawModal.member.nickname} 탈퇴 처리</span>
              <button className="modal-close" onClick={() => { setWithdrawModal(null); setWithdrawReason(""); }}>×</button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <textarea
                autoFocus
                placeholder="탈퇴 사유 (선택)"
                value={withdrawReason}
                onChange={(e) => setWithdrawReason(e.target.value)}
                rows={3}
                style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 14, resize: "vertical" }}
              />
              <div style={{ display: "flex", gap: 8 }}>
                <button className="withdraw-btn" style={{ flex: 1 }} onClick={submitWithdraw}>탈퇴 처리</button>
                <button className="cancel-btn" style={{ flex: 1 }} onClick={() => { setWithdrawModal(null); setWithdrawReason(""); }}>취소</button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* 블랙리스트 모달 */}
      {blacklistModal && (
        <div className="modal-backdrop">
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 480 }}>
            <div className="modal-head">
              <span>💀 {blacklistModal.nickname} 블랙리스트</span>
              <button className="modal-close" onClick={() => setBlacklistModal(null)}>×</button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
              <input type="date" value={blacklistForm.addedAt} onChange={(e) => setBlacklistForm((p) => ({ ...p, addedAt: e.target.value }))}
                style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 14 }} />
              <textarea value={blacklistForm.reason} onChange={(e) => setBlacklistForm((p) => ({ ...p, reason: e.target.value }))}
                placeholder="사유 (선택)" rows={2}
                style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 14, resize: "vertical" }} />
              <button className="sync-btn" onClick={async () => {
                const res = await fetch("/api/userinfo/blacklist", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ memberId: blacklistModal.memberId, reason: blacklistForm.reason, addedAt: blacklistForm.addedAt }),
                });
                if (!res.ok) { alert("추가 실패"); return; }
                const r2 = await fetch(`/api/userinfo/blacklist?memberId=${blacklistModal.memberId}`);
                const j2 = await r2.json();
                setBlacklistModal((p) => p ? { ...p, entries: j2.blacklist } : null);
                loadMembers();
              }}>블랙 추가</button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {blacklistModal.entries.length === 0 && <p className="empty">블랙 내역이 없습니다.</p>}
              {blacklistModal.entries.map((b) => (
                <div key={b.id} style={{ display: "flex", alignItems: "center", gap: 8, background: "var(--card-2)", borderRadius: 8, padding: "8px 12px", fontSize: 13 }}>
                  {editingBlackId === b.id ? (
                    <div style={{ display: "flex", flexDirection: "column", gap: 6, width: "100%" }}>
                      <input type="date" value={editingBlackForm.addedAt} onChange={e => setEditingBlackForm(p => ({ ...p, addedAt: e.target.value }))}
                        style={{ padding: "5px 8px", borderRadius: 6, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 12 }} />
                      <div style={{ display: "flex", gap: 6 }}>
                        <input value={editingBlackForm.reason} onChange={e => setEditingBlackForm(p => ({ ...p, reason: e.target.value }))} placeholder="사유"
                          style={{ flex: 1, padding: "5px 8px", borderRadius: 6, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 12 }} />
                        <button className="sync-btn" style={{ fontSize: 11, padding: "2px 12px", whiteSpace: "nowrap" }} onClick={async () => {
                          await fetch("/api/userinfo/blacklist", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: b.id, ...editingBlackForm }) });
                          setEditingBlackId(null);
                          const r2 = await fetch(`/api/userinfo/blacklist?memberId=${blacklistModal.memberId}`);
                          const j2 = await r2.json();
                          setBlacklistModal(p => p ? { ...p, entries: j2.blacklist } : null);
                        }}>저장</button>
                        <button className="cancel-btn" style={{ fontSize: 11, padding: "2px 10px", whiteSpace: "nowrap" }} onClick={() => setEditingBlackId(null)}>취소</button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <span style={{ fontWeight: 800, color: "#f1948a", flexShrink: 0 }}>{b.added_at?.slice(0, 10)}</span>
                      <span style={{ flex: 1, color: "var(--muted)" }}>{b.reason || "-"}</span>
                      <button className="sync-btn" style={{ fontSize: 11, padding: "2px 10px" }} onClick={() => { setEditingBlackId(b.id); setEditingBlackForm({ reason: b.reason || "", addedAt: b.added_at?.slice(0, 10) ?? "" }); }}>수정</button>
                      <button className="del-btn small" onClick={async () => {
                        await fetch(`/api/userinfo/blacklist?id=${b.id}`, { method: "DELETE" });
                        const r2 = await fetch(`/api/userinfo/blacklist?memberId=${blacklistModal.memberId}`);
                        const j2 = await r2.json();
                        setBlacklistModal((p) => p ? { ...p, entries: j2.blacklist } : null);
                      }}>삭제</button>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
      {/* 클랜원 추가 모달 */}
      {memberModal && (
        <div className="modal-backdrop">
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 400 }}>
            <div className="modal-head">
              <span>클랜원 추가</span>
              <button className="modal-close" onClick={() => setMemberModal(false)}>×</button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <p style={{ fontSize: 13, color: "var(--muted)", margin: 0 }}>본계정 Riot ID를 입력하세요. 솔로랭크 티어가 자동 조회됩니다.</p>
              <input
                autoFocus
                placeholder="소환사명#태그 (예: 소환사#KR1)"
                value={memberInput}
                onChange={(e) => setMemberInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") submitMemberModal(); }}
                style={{ padding: "9px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 14 }}
              />
              {memberModalErr && <span style={{ fontSize: 12, color: "var(--loss-text)" }}>{memberModalErr}</span>}
              <div style={{ display: "flex", gap: 8 }}>
                <button className="sync-btn" disabled={memberModalBusy} onClick={submitMemberModal} style={{ flex: 1 }}>
                  {memberModalBusy ? "조회 중... (티어 조회 포함)" : "추가"}
                </button>
                <button className="cancel-btn" disabled={memberModalBusy} onClick={() => setMemberModal(false)} style={{ flex: 1 }}>
                  취소
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* 클랜원 수정 모달 */}
      {/* 클랜원 수정 모달 */}
      {editModal && (
        <div className="modal-backdrop">
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 560, width: "100%" }}>
            <div className="modal-head">
              <span>✏️ {editModal.nickname} 수정</span>
              <button className="modal-close" onClick={() => setEditModal(null)}>×</button>
            </div>
            {/* 기본 정보 */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 16 }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <label style={{ fontSize: 11, color: "var(--muted)" }}>출생연도</label>
                <input type="number" placeholder="1995" value={editForm.birthYear}
                  onChange={(e) => setEditForm((p) => ({ ...p, birthYear: e.target.value }))}
                  style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }} />
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <label style={{ fontSize: 11, color: "var(--muted)" }}>생일 (MM-DD)</label>
                <input type="text" placeholder="03-15" value={editForm.birthMD}
                  onChange={(e) => {
                    const raw = e.target.value;
                    const digits = raw.replace(/[^0-9]/g, "");
                    let v = digits.length >= 4 ? digits.slice(0, 2) + "-" + digits.slice(2, 4) : raw;
                    setEditForm((p) => ({ ...p, birthMD: v }));
                  }}
                  style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }} />
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <label style={{ fontSize: 11, color: "var(--muted)" }}>성별</label>
                <select value={editForm.gender} onChange={(e) => setEditForm((p) => ({ ...p, gender: e.target.value }))}
                  style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }}>
                  <option value="">미선택</option>
                  <option value="M">남</option>
                  <option value="F">여</option>
                </select>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <label style={{ fontSize: 11, color: "var(--muted)" }}>직책</label>
                <select value={editForm.position} onChange={(e) => setEditForm((p) => ({ ...p, position: e.target.value }))}
                  style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }}>
                  <option value="클랜원">클랜원</option>
                  <option value="수습">수습</option>
                  <option value="부운영진">부운영진</option>
                  <option value="운영진">운영진</option>
                </select>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <label style={{ fontSize: 11, color: "var(--muted)" }}>활동상태</label>
                <select value={editForm.status} onChange={(e) => setEditForm((p) => ({ ...p, status: e.target.value }))}
                  style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }}>
                  <option value="active">활동</option>
                  <option value="leave">외출/예외</option>
                  <option value="withdraw">탈퇴</option>
                  <option value="black">블랙</option>
                </select>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <label style={{ fontSize: 11, color: "var(--muted)" }}>내전 티어</label>
                <select value={editForm.scrimTier} onChange={(e) => { const t=e.target.value; setEditForm((p) => ({ ...p, scrimTier: t, scrimMmr: SCRIM_TIER_INITIAL[t] ?? 0 })); }}
                  style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }}>
                  {SCRIM_TIERS.map((t) => (
                    <option key={t} value={t}>{SCRIM_TIER_KO[t]} ({SCRIM_TIER_INITIAL[t]})</option>
                  ))}
                </select>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <label style={{ fontSize: 11, color: "var(--muted)" }}>주라인</label>
                <select value={editForm.mainLine} onChange={(e) => setEditForm((p) => ({ ...p, mainLine: e.target.value }))}
                  style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }}>
                  <option value="">미선택</option>
                  <option value="TOP">TOP</option><option value="JG">JG</option>
                  <option value="MID">MID</option><option value="ADC">ADC</option>
                  <option value="SUP">SUP</option>
                  <option value="ARAM">ARAM</option>
                </select>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <label style={{ fontSize: 11, color: "var(--muted)" }}>부라인</label>
                <select value={editForm.subLine} onChange={(e) => setEditForm((p) => ({ ...p, subLine: e.target.value }))}
                  style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }}>
                  <option value="">미선택</option>
                  <option value="ALL">ALL</option>
                  <option value="TOP">TOP</option><option value="JG">JG</option>
                  <option value="MID">MID</option><option value="ADC">ADC</option>
                  <option value="SUP">SUP</option>
                </select>
              </div>
              {editForm.status === "leave" && (
                <div style={{ display: "flex", flexDirection: "column", gap: 4, gridColumn: "1 / -1" }}>
                  <label style={{ fontSize: 11, color: "var(--muted)" }}>외출 사유</label>
                  <input value={editForm.statusNote} onChange={(e) => setEditForm((p) => ({ ...p, statusNote: e.target.value }))}
                    placeholder="외출 사유"
                    style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }} />
                </div>
              )}
            </div>
            {/* 연동 계정 */}
            {/* 연동 계정 */}
            <div style={{ borderTop: "1px solid var(--border)", paddingTop: 12, marginBottom: 12 }}>
              <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 8, fontWeight: 700 }}>연동 계정</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {editModal.accounts.map((a) => (
                  <div key={a.id} style={{ display: "flex", alignItems: "center", gap: 8,
                    background: "var(--card-2)", borderRadius: 8, padding: "7px 10px", fontSize: 13 }}>
                    <span style={{ flex: 1, fontWeight: 700 }}>{a.gameName}<span style={{ color: "var(--muted)", fontWeight: 400 }}>#{a.tagLine}</span></span>
                    {a.isMain && (
                      <span style={{ fontSize: 10, fontWeight: 800, padding: "2px 6px", borderRadius: 4, background: "rgba(83,131,232,0.18)", color: "var(--win-text)" }}>본계정</span>

                    )}
                    <span style={{ fontSize: 11, color: "var(--muted)" }}>{syncedTime(a.lastSyncedAt)}</span>
                    {!a.isMain && (
                      <button className="sync-btn" style={{ fontSize: 11, padding: "2px 8px", whiteSpace: "nowrap" }} onClick={async () => {
                        await fetch("/api/userinfo/account", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ accountId: a.id, memberId: editModal!.id }) });
                        const updated = await fetch("/api/userinfo").then((r) => r.json());
                        const fresh = (updated.members as Member[]).find((m) => m.id === editModal!.id);
                        if (fresh) setEditModal(fresh);
                        loadMembers();
                      }}>본계정 변경</button>
                    )}
                    <button className="del-btn small" onClick={async () => {
                      if (!confirm(`"${a.gameName}#${a.tagLine}" 계정을 삭제하시겠습니까?`)) return;
                      await fetch("/api/userinfo/delete", { method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ kind: "account", id: a.id }) });
                      await loadMembers();
                      setEditModal((prev) => prev ? { ...prev, accounts: prev.accounts.filter((x) => x.id !== a.id) } : null);
                    }}>
                      삭제
                    </button>
                  </div>
                ))}
                {editModal.accounts.length === 0 && <p style={{ fontSize: 12, color: "var(--muted)", margin: 0 }}>연동된 계정이 없습니다.</p>}
              </div>
            {/* 계정 추가 폼 */}
            </div>
            {/* 계정 추가 폼 */}
            <div style={{ display: "flex", gap: 8, marginBottom: 16, alignItems: "center" }}>
              <input
                placeholder="소환사명#태그"
                value={accInput}
                onChange={(e) => setAccInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") submitAccFromEditModal(); }}
                style={{ flex: 1, padding: "8px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }}
              />
              <label style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, cursor: "pointer", whiteSpace: "nowrap" }}>
                <input type="checkbox" checked={accIsMain} onChange={(e) => setAccIsMain(e.target.checked)} />
                본계정
              </label>
              <button className="sync-btn" style={{ whiteSpace: "nowrap" }} disabled={accModalBusy} onClick={submitAccFromEditModal}>
                {accModalBusy ? "추가 중..." : "+ 계정 추가"}
              </button>
            </div>
            {/* 경고 내역 */}
            {warnings.length > 0 && (
              <div style={{ borderTop: "1px solid var(--border)", paddingTop: 12, marginBottom: 12 }}>
                <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 6, fontWeight: 700 }}>⚠️ 경고 {warnings.length}건</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  {warnings.map((w) => (
                    <div key={w.id} style={{ display: "flex", alignItems: "center", gap: 8,
                      background: "var(--card-2)", borderRadius: 8, padding: "7px 10px", fontSize: 12 }}>
                      <span style={{ color: "#f1948a", fontWeight: 800, flexShrink: 0 }}>{w.warned_at?.slice(0, 10)}</span>
                      <span style={{ fontWeight: 700, flexShrink: 0, background: "rgba(231,76,60,0.18)",
                        color: "#f1948a", padding: "2px 6px", borderRadius: 4, fontSize: 11 }}>{w.type}</span>
                      <span style={{ flex: 1, color: "var(--muted)", minWidth: 0 }}>{w.reason || "-"}</span>
                      <button className="del-btn small" onClick={() => deleteWarning(w.id)}>삭제</button>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {/* 저장 / 취소 */}
            <div style={{ display: "flex", gap: 8 }}>
              <button className="sync-btn" style={{ flex: 1 }} onClick={saveEdit}>저장</button>
              <button className="sync-btn" style={{ flex: 1 }} disabled={syncingId === editModal.id}
                onClick={() => syncTier(editModal.id)}>
                {syncingId === editModal.id ? "동기화 중..." : "🔄 솔랭 동기화"}
              </button>
              <button className="cancel-btn" style={{ flex: 1 }} onClick={() => setEditModal(null)}>취소</button>
            </div>
          </div>
        </div>
      )}
      {/* 계정 추가 모달 */}
      {/* 계정 추가 모달 */}
      {accModal && (
        <div className="modal-backdrop">
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 400 }}>
            <div className="modal-head">
              <span>계정 추가 — {accModal.nickname}</span>
              <button className="modal-close" onClick={() => setAccModal(null)}>×</button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <input
                autoFocus
                placeholder="소환사명#태그 (예: 소환사#KR1)"
                value={accInput}
                onChange={(e) => setAccInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") submitAccModal(); }}
                style={{ padding: "9px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 14 }}
              />
              <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, cursor: "pointer" }}>
                <input type="checkbox" checked={accIsMain} onChange={(e) => setAccIsMain(e.target.checked)} />
                본계정
              </label>
              {accModalErr && <span style={{ fontSize: 12, color: "var(--loss-text)" }}>{accModalErr}</span>}
              <button className="sync-btn" disabled={accModalBusy} onClick={submitAccModal}>
                {accModalBusy ? "추가 중..." : "계정 추가"}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* 포인트 지급 모달 */}
      {/* 포인트 지급 모달 */}

      {/* 수습 파티 로그 모달 */}
      {rookieLogModal && (
        <div className="modal-backdrop">
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 400 }}>
            <div className="modal-head">
              <span>{rookieLogModal.nickname} 파티 로그</span>
              <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                {isAdmin && (
                  <button className="sync-btn" style={{ fontSize: 11, padding: "2px 10px" }}
                    onClick={() => { setRookieEventErr(""); setRookieEventOpen(p => !p); setRookieEventForm(""); }}>
                    + 추가
                  </button>
                )}
                <button className="modal-close" onClick={() => { setRookieLogModal(null); setRookieEventForm(""); setRookieEventOpen(false); setRookieEventErr(""); }}>✕</button>
              </div>
            </div>
            {rookieEventOpen && isAdmin && (
              <div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 10 }}>
                <input autoFocus placeholder="사유 (예: 이벤트 매치 참여)" value={rookieEventForm}
                  onChange={(e) => setRookieEventForm(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") submitRookieEvent(); }}
                  style={{ flex: 1, padding: "7px 10px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }} />
                <button className="sync-btn" style={{ whiteSpace: "nowrap", fontSize: 12 }} disabled={rookieEventBusy} onClick={submitRookieEvent}>
                  {rookieEventBusy ? "..." : "확인"}
                </button>
              </div>
            )}
            {rookieEventErr && <div style={{ fontSize: 12, color: "var(--loss-text)", marginBottom: 6 }}>{rookieEventErr}</div>}
            {(() => {
              const allPlayed = new Set(
                rookieLogModal.logs.flatMap(log => log.members ?? [])
              );
              return (
                <div style={{ fontSize: 13, color: "var(--muted)", marginBottom: 8 }}>
                  같이 플레이한 클랜원 <span style={{ fontWeight: 800, color: "var(--text)" }}>{allPlayed.size}명</span>
                </div>
              );
            })()}
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {rookieLogModal.logs.map((log, i) => (
                <div key={i} style={{ borderBottom: "1px solid var(--border)", paddingBottom: 8 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "var(--muted)", marginBottom: 4 }}>
                    <span>{log.startAt || log.date}</span>
                    <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                      <span style={{ fontSize: 11, padding: "1px 6px", borderRadius: 4, background: "var(--card-2)", color: "var(--muted)" }}>{MODE_KO[log.mode] ?? log.mode}</span>
                      <span style={{ fontWeight: 700, color: "var(--win-text)" }}>{log.mode === "scrim" ? `${log.games}판` : (log.partyCount ?? 0) > 0 ? `${log.partyCount}회 참여` : "참여"}</span>
                      {isAdmin && log.id && (
                        <button className="del-btn small" style={{ fontSize: 10, padding: "1px 6px" }} onClick={async () => {
                          if (!confirm(`"${rookieLogModal.nickname}"의 ${log.startAt || log.date} 로그를 삭제하시겠습니까?`)) return;
                          const res = await fetch(`/api/points?id=${log.id}`, { method: "DELETE" });
                          if (!res.ok) { alert("삭제 실패"); return; }
                          await loadMembers();
                          setMembers((prev) => {
                            const fresh = prev.find((m) => m.id === rookieLogModal.memberId);
                            if (fresh) setRookieLogModal({ memberId: fresh.id, nickname: fresh.nickname, logs: fresh.rookieSessionLogs ?? [] });
                            return prev;
                          });
                        }}>삭제</button>
                      )}
                    </div>
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                    {(log.members ?? []).length > 0
                      ? log.members.map((nick: string) => (
                          <span key={nick} style={{ fontSize: 12, padding: "2px 8px", borderRadius: 10, background: "var(--card-2)", color: "var(--text)", fontWeight: 700 }}>{nick}</span>
                        ))
                      : log.mode === "event" ? null : <span style={{ fontSize: 11, color: "var(--muted)" }}>클랜원 정보 없음</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 판수미달 파티 로그 모달 */}
      {inactiveLogModal && (
        <div className="modal-backdrop">
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 420 }}>
            <div className="modal-head">
              <span>{inactiveLogModal.nickname} 최근 1달 플레이</span>
              <button className="modal-close" onClick={() => setInactiveLogModal(null)}>✕</button>
            </div>
            {inactiveLogModal.logs.length === 0 ? (
              <p style={{ color: "var(--muted)", fontSize: 13 }}>최근 1달 플레이 내역이 없습니다.</p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {(() => {
                  const member = members.find(m => m.id === inactiveLogModal.memberId);
                  const achievedAt = (member as any)?.lastAchievedAt;
                  let achievedMarked = false;
                  return inactiveLogModal.logs.map((log, i) => {
                  const isAchieved = !achievedMarked && achievedAt && log.date === achievedAt;
                  if (isAchieved) achievedMarked = true;
                  return (
                  <div key={i} style={{ borderBottom: "1px solid var(--border)", paddingBottom: 8 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "var(--muted)", marginBottom: 4 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span>{log.startAt}</span>
                        {isAchieved && <span style={{ fontSize: 10, fontWeight: 800, padding: "1px 6px", borderRadius: 4, background: "rgba(46,204,113,0.2)", color: "#2ecc71", border: "1px solid rgba(46,204,113,0.4)" }}>✅ 달성일 갱신</span>}
                      </div>
                      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                        <span style={{ fontSize: 11, padding: "1px 6px", borderRadius: 4, background: "var(--card-2)", color: "var(--muted)" }}>{MODE_KO[log.mode] ?? log.mode}</span>
                        <span style={{ fontWeight: 700, color: "var(--win-text)" }}>{log.games}판</span>
                        {isAdmin && log.id && (
                          <button className="del-btn small" style={{ fontSize: 10, padding: "1px 6px" }} onClick={async () => {
                            if (!confirm(`"${inactiveLogModal.nickname}"의 ${log.startAt} 로그를 삭제하시겠습니까?`)) return;
                            const res = await fetch(`/api/points?id=${log.id}`, { method: "DELETE" });
                            if (!res.ok) { alert("삭제 실패"); return; }
                            await loadMembers();
                            setMembers((prev) => {
                              const fresh = prev.find((m) => m.id === inactiveLogModal.memberId);
                              if (fresh) setInactiveLogModal({ memberId: fresh.id, nickname: fresh.nickname, logs: fresh.recentLogs ?? [] });
                              return prev;
                            });
                          }}>삭제</button>
                        )}
                      </div>
                    </div>
                    {log.members.length > 0 && (
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                        {log.members.map((nick: string) => (
                          <span key={nick} style={{ fontSize: 12, padding: "2px 8px", borderRadius: 10, background: "var(--card-2)", color: "var(--text)", fontWeight: 700 }}>{nick}</span>
                        ))}
                      </div>
                    )}
                  </div>
                  );
                  });
                })()}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 경고 관리 모달 */}
      {/* 경고 관리 모달 */}
      {warnModal && (
        <div className="modal-backdrop">
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 520 }}>
            <div className="modal-head">
              <span>⚠️ {warnModal.nickname} 경고 관리</span>
              <button className="modal-close" onClick={() => setWarnModal(null)}>×</button>
            </div>
            {/* 경고 추가 폼 */}
            {/* 경고 추가 폼 */}
            <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
              <select value={warnForm.type} onChange={(e) => setWarnForm((p) => ({ ...p, type: e.target.value }))}
                style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 14 }}>
                <option>운영 방침 위반</option>
                <option>지각 및 노쇼</option>
                <option>판수 미달</option>
                <option>불화 조장</option>
              </select>
              <input type="date" value={warnForm.warnedAt} onChange={(e) => setWarnForm((p) => ({ ...p, warnedAt: e.target.value }))}
                style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 14 }} />
              <textarea value={warnForm.reason} onChange={(e) => setWarnForm((p) => ({ ...p, reason: e.target.value }))}
                placeholder="상세 사유 (선택)"
                rows={2}
                style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 14, resize: "vertical" }} />
              <button className="sync-btn" onClick={addWarning}>경고 추가</button>
            </div>
            {/* 경고 이력 */}
            {/* 경고 이력 */}
            {warnLoading ? <p className="empty">불러오는 중...</p> : (
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {warnings.length === 0 && <p className="empty">경고 내역이 없습니다.</p>}
                {warnings.map((w) => (
                  <div key={w.id} style={{ display: "flex", alignItems: "center", gap: 8, background: "var(--card-2)", borderRadius: 8, padding: "8px 12px", fontSize: 13 }}>
                    {editingWarnId === w.id ? (
                      <div style={{ display: "flex", flexDirection: "column", gap: 6, width: "100%" }}>
                        <div style={{ display: "flex", gap: 6 }}>
                          <select value={editingWarnForm.type} onChange={e => setEditingWarnForm(p => ({ ...p, type: e.target.value }))}
                            style={{ flex: 1, padding: "5px 8px", borderRadius: 6, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 12 }}>
                            <option>운영 방침 위반</option><option>지각 및 노쇼</option><option>판수 미달</option><option>불화 조장</option>
                          </select>
                          <input type="date" value={editingWarnForm.warnedAt} onChange={e => setEditingWarnForm(p => ({ ...p, warnedAt: e.target.value }))}
                            style={{ padding: "5px 8px", borderRadius: 6, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 12 }} />
                        </div>
                        <div style={{ display: "flex", gap: 6 }}>
                          <input value={editingWarnForm.reason} onChange={e => setEditingWarnForm(p => ({ ...p, reason: e.target.value }))} placeholder="사유"
                            style={{ flex: 1, padding: "5px 8px", borderRadius: 6, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 12 }} />
                          <button className="sync-btn" style={{ fontSize: 11, padding: "2px 12px", whiteSpace: "nowrap" }} onClick={() => saveWarning(w.id, warnModal!.memberId)}>저장</button>
                          <button className="cancel-btn" style={{ fontSize: 11, padding: "2px 10px", whiteSpace: "nowrap" }} onClick={() => setEditingWarnId(null)}>취소</button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <span style={{ fontWeight: 800, color: "#f1948a", flexShrink: 0 }}>{w.warned_at?.slice(0, 10)}</span>
                        <span style={{ fontWeight: 700, flexShrink: 0, background: "rgba(231,76,60,0.18)", color: "#f1948a", padding: "2px 7px", borderRadius: 5, fontSize: 11 }}>{w.type}</span>
                        <span style={{ flex: 1, color: "var(--muted)", minWidth: 0 }}>{w.reason || "-"}</span>
                        <button className="sync-btn" style={{ fontSize: 11, padding: "2px 10px" }} onClick={() => { setEditingWarnId(w.id); setEditingWarnForm({ type: w.type, reason: w.reason || "", warnedAt: w.warned_at?.slice(0, 10) ?? "" }); }}>수정</button>
                        <button className="del-btn small" onClick={() => deleteWarning(w.id)}>삭제</button>
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
      <div className="ui-page-head">
        <div>
          <h2>{isAdmin ? "클랜원 관리" : "클랜원"}</h2>
          <p>클랜원 명단 · 티어 · 활동 상태{isAdmin ? " · 경고 / 탈퇴 관리" : ""}</p>
        </div>
        {isAdmin && tab === "members" && (
          <div className="ui-page-actions">
            <button className="btn-secondary" onClick={downloadTemplate}>양식 다운로드</button>
            <label htmlFor="excel-file" className="btn-secondary" style={{ cursor: "pointer" }}>엑셀 업로드</label>
            <input type="file" id="excel-file" accept=".xlsx,.xls" style={{ display: "none" }} onChange={handleFileUpload} />
            <button className="btn-primary" onClick={() => { setMemberModal(true); setMemberInput(""); setMemberModalErr(""); }}>+ 클랜원 추가</button>
          </div>
        )}
      </div>
      <div className="ui-tabs">
        {user?.role === "admin" && <button className={tab === "accounts" ? "on" : ""} onClick={() => setTab("accounts")}>로그인 계정</button>}
        <button className={tab === "members" ? "on" : ""} onClick={() => setTab("members")}>클랜원</button>
        <button className={tab === "party-history" ? "on" : ""} onClick={() => setTab("party-history")}>파티 내역</button>
      </div>
      {linkMsg && <div className="error">{linkMsg}</div>}
      {error && <div className="error">{error}</div>}
      {/* 검색창 (클랜원 탭에서만 표시) */}
      {/* 검색창 */}
      {tab === "members" && (
      <div className="ui-toolbar">
        <div className="ui-search">
          <span className="ic">⌕</span>
          <input
            type="text"
            placeholder="이름 또는 출생연도 검색"
            value={searchQuery}
            onChange={(e) => { setSearchQuery(e.target.value); setPage(0); }}
            onKeyDown={(e) => { if (e.key === "Enter") e.currentTarget.blur(); }}
          />
          {searchQuery && <button className="clr" onClick={() => setSearchQuery("")}>✕</button>}
        </div>
        <div className="ui-filter-chips">
          <button className={`ui-chip ${showInactive ? "on" : ""}`} onClick={() => { setShowInactive(!showInactive); setSpecialFilter(""); setPage(0); }}>
            판수미달
          </button>
          <button className={`ui-chip ${specialFilter === "rookie" ? "on" : ""}`} onClick={() => { setSpecialFilter(specialFilter === "rookie" ? "" : "rookie"); setShowInactive(false); setPage(0); }}>
            수습
          </button>
          <button className={`ui-chip ${specialFilter === "leave" ? "on" : ""}`} onClick={() => { setSpecialFilter(specialFilter === "leave" ? "" : "leave"); setShowInactive(false); setPage(0); }}>
            외출
          </button>
          <button className={`ui-chip ${specialFilter === "warn" ? "on" : ""}`} onClick={() => { setSpecialFilter(specialFilter === "warn" ? "" : "warn"); setShowInactive(false); setPage(0); }}>
            경고
          </button>
          <button className={`ui-chip ${specialFilter === "withdraw" ? "on" : ""}`} onClick={() => { setSpecialFilter(specialFilter === "withdraw" ? "" : "withdraw"); setShowInactive(false); setPage(0); }}>
            탈퇴
          </button>
        </div>
      </div>
      )}
      {tab === "members" && uploading && <div className="sync-msg">엑셀 업로드 중...</div>}
      {tab === "members" && uploadMsg && <div className="sync-msg">{uploadMsg}</div>}
      {/* 로그인 계정 탭 */}
      {/* 로그인 계정 탭 */}
      {isAdmin && user?.role === "admin" && tab === "accounts" && (
        <div className="home-panel">
          <div className="home-panel-head"><h3>계정 목록</h3></div>
          <table className="ui-table">
            <thead>
              <tr>
                <th style={{ textAlign: "left", padding: "6px 8px" }}>아이디</th>
                <th style={{ textAlign: "left", padding: "6px 8px" }}>닉네임</th>
                <th style={{ textAlign: "left", padding: "6px 8px" }}>상태</th>
                <th style={{ textAlign: "left", padding: "6px 8px" }}>권한</th>
                <th style={{ textAlign: "right", padding: "6px 8px" }}>관리</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} style={{ borderBottom: "1px solid var(--border)", background: u.status === "pending" ? "rgba(231,76,60,0.06)" : undefined }}>
                  <td style={{ padding: "8px", fontWeight: 700 }}>{u.username}</td>
                  <td style={{ padding: "8px" }}>{u.nickname}</td>
                  <td style={{ padding: "8px" }}>
                    {u.status === "pending" ? (
                      <span style={{ fontSize: 11, fontWeight: 800, padding: "2px 7px", borderRadius: 5, background: "rgba(231,76,60,0.18)", color: "#f1948a" }}>승인 대기</span>
                    ) : (
                      <span style={{ fontSize: 11, fontWeight: 800, padding: "2px 7px", borderRadius: 5, background: "rgba(46,204,113,0.18)", color: "#2ecc71" }}>승인</span>
                    )}
                  </td>
                  <td style={{ padding: "8px" }}>
                    {user?.role === "admin" ? (
                      <select value={u.scrimOnly ? "scrim" : u.role} onChange={(e) => changeRole(u.id, e.target.value)}
                        style={{ padding: "4px 8px", borderRadius: 6, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text)", fontSize: 13 }}>
                        <option value="member">일반</option>
                        <option value="captain">팀장</option>
                        <option value="scrim">내전</option>
                        <option value="subadmin">부운영진</option>
                        <option value="admin">운영진</option>
                      </select>
                    ) : (
                      <span className={`auth-role-badge ${u.role}`}>{u.role === "admin" ? "운영진" : u.role === "subadmin" ? "부운영진" : u.role === "captain" ? "팀장" : u.scrimOnly ? "내전" : "일반"}</span>
                    )}
                  </td>
                  <td style={{ padding: "8px", textAlign: "right", whiteSpace: "nowrap" }}>
                    {u.status === "pending" && (
                      <><button className="sync-btn" style={{ fontSize: 11, padding: "3px 10px" }} onClick={() => approveUser(u.id, u.username)}>승인</button>{" "}</>
                    )}
                    <button
                      onClick={async () => {
                        const res = await fetch("/api/userinfo/link", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId: u.id, showRoster: !u.showRoster }) });
                        if (res.ok) loadUsers();
                      }}
                      style={{ fontSize: 11, padding: "3px 10px", borderRadius: 6, border: `1px solid ${u.showRoster ? "rgba(46,204,113,0.5)" : "rgba(var(--fg-rgb),0.15)"}`, background: u.showRoster ? "rgba(46,204,113,0.15)" : "transparent", color: u.showRoster ? "#2ecc71" : "var(--muted)", cursor: "pointer", fontWeight: 700 }}
                    >참여자{u.showRoster ? " ON" : " OFF"}</button>
                    {" "}
                    <button className="reset-pw-btn" onClick={() => resetPassword(u.id, u.username)}>비밀번호 초기화</button>
                    {" "}
                    <button className="del-btn small" onClick={() => deleteUser(u.id, u.username)}>삭제</button>
                  </td>
                </tr>
              ))}
              {users.length === 0 && (
                <tr><td colSpan={5} style={{ padding: "12px 8px", color: "var(--muted)" }}>로그인 계정이 없습니다.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
      {/* 파티 내역 탭 */}
      {/* 파티 내역 탭 */}
      {isAdmin && tab === "party-history" && (
        <div>
          {historyLoading && <p className="party-empty">불러오는 중...</p>}
          {!historyLoading && historyData && (
            historyData.parties.length === 0
              ? <p className="empty">펑한 파티 내역이 없습니다.</p>
              : <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
                  {historyData.parties.map((p) => (
                    <div key={p.id} className="home-panel" style={{ padding: "12px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6, flexWrap: "wrap" }}>
                        <span className={`party-mode-badge mode-${p.mode}`}>{MODE_KO[p.mode] ?? p.mode}</span>
                        {p.note && <span style={{ fontWeight: 700, fontSize: 13 }}>{p.note}</span>}
                        <span style={{ fontSize: 11, color: "var(--muted)", marginLeft: "auto" }}>{p.startAt ? p.startAt.slice(5, 16).replace("T", " ") : "-"}</span>
                        <span style={{ fontSize: 11, fontWeight: 800, padding: "2px 7px", borderRadius: 5, background: "rgba(231,76,60,0.18)", color: "#f1948a" }}>펑{p.endedBy ? ` (${p.endedBy})` : ""}</span>
                      </div>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                        {p.participants.map((nick) => (
                          <span key={nick} style={{ fontSize: 12, padding: "2px 8px", borderRadius: 12, background: "var(--card-2)", color: "var(--text)" }}>{nick}</span>
                        ))}
                        {p.participants.length === 0 && <span style={{ fontSize: 12, color: "var(--muted)" }}>참가자 없음</span>}
                        {p.pastParticipants.length > 0 && (
                          <div style={{ marginTop: 6, paddingTop: 6, borderTop: "1px solid var(--border)", width: "100%" }}>
                            <span style={{ fontSize: 11, color: "var(--muted)", marginBottom: 4, display: "block" }}>이전 참가자</span>
                            <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                              {p.pastParticipants.map((nick) => (
                                <span key={nick} style={{ fontSize: 11, padding: "2px 7px", borderRadius: 12, background: "var(--card-2)", color: "var(--muted)", textDecoration: "line-through" }}>{nick}</span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
          )}
        </div>
      )}
      {/* 클랜원 목록 */}
      {/* 클랜원 목록 */}
      {tab === "members" && (<>
      <div style={{ maxWidth: 1400, margin: "0 auto" }}>
      {isAdmin && !loading && members.length > 0 && (
        <div className="line-filter-bar" style={{ marginBottom: 18 }}>
          {(() => {
            const activeMembers = members.filter((m) => m.status !== "withdraw" && m.status !== "black");
            return (
              <>
                <button
                  className={`line-filter-btn ${lineFilter === "" ? "on" : ""}`}
                  onClick={() => { setLineFilter(""); setPage(0); }}
                >
                  전체 <em>{activeMembers.length}</em>
                </button>
                {LINE_KEYS.map((lk) => (
                  <button
                    key={lk}
                    className={`line-filter-btn ${lineFilter === lk ? "on" : ""}`}
                    onClick={() => { setLineFilter(lk); setPage(0); }}
                  >
                    {lk} <em>{activeMembers.filter((m) => m.mainLine === lk).length}</em>
                  </button>
                ))}
              </>
            );
          })()}
          <button
            style={{ marginLeft: "auto", padding: "4px 14px", borderRadius: 8, border: "1px solid #27ae60", background: sortBy === "activityTier" ? "#27ae60" : "transparent", color: sortBy === "activityTier" ? "#fff" : "#2ecc71", fontWeight: 700, fontSize: 13, cursor: "pointer" }}
            onClick={() => { setSortBy(sortBy === "activityTier" ? "birth" : "activityTier"); setPage(0); }}
          >
            활동티어
          </button>
        </div>
      )}
      {/* 클랜원 추가 + 전체 티어 동기화 버튼 */}
      {/* 클랜원 추가 + 전체 티어 동기화 */}

      {/* 페이지네이션 */}
      {/* 페이지네이션 */}
      {members.length > 0 && (
        <div className="pager">
          <div className="page-size">
            표시
            {PAGE_SIZES.map((s) => (

              <button
                key={s}
                className={pageSize === s ? "on" : ""}
                onClick={() => {
                  setPageSize(s);
                  setPage(0);
                }}
              >
                {s}명
              </button>
            ))}
          </div>
          <div className="page-nav">
            <button
              disabled={safePage <= 0}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
            >
              ‹
            </button>
            <span>
              {safePage + 1} / {totalPages}{showInactive ? ` (판수미달 ${filteredMembers.length} / 전체 ${members.length})` : specialFilter === "rookie" ? ` (신입 ${filteredMembers.length} / 전체 ${members.length})` : specialFilter === "leave" ? ` (외출 ${filteredMembers.length} / 전체 ${members.length})` : lineFilter ? ` (${lineFilter} ${filteredMembers.length} / 전체 ${members.length})` : searchQuery ? ` (검색 ${filteredMembers.length} / 전체 ${members.length})` : ` (전체 ${members.length})`}
            </span>
            <button
              disabled={safePage >= totalPages - 1}
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
            >
              ›
            </button>
          </div>
        </div>
      )}

      {loading && <p>불러오는 중...</p>}
      {!loading && filteredMembers.length === 0 && (showInactive || specialFilter || searchQuery) && (
        <p>{showInactive ? "최근 2주 판수 미달 클랜원이 없습니다." : specialFilter === "rookie" ? "신입 클랜원이 없습니다." : specialFilter === "leave" ? "외출 중인 클랜원이 없습니다." : "검색 결과가 없습니다."}</p>
      )}
      {!loading && members.length === 0 && !searchQuery && !showInactive && (
        <p>등록된 클랜원이 없습니다.</p>
      )}

      {showInactive ? (
        <div className="ui-table-wrap">
          <table className="ui-table">
            <thead>
              <tr>
                <th style={{ textAlign: "left", padding: "6px 10px" }}>닉네임</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>칼바람(2판=협곡1판)</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>협곡(일반+자랭+내전)</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>달성일</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>마감일</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>플레이 로그</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>갱신</th>
              </tr>
            </thead>
            <tbody>
              {pagedMembers.map((m) => (
                <tr key={m.id}>
                  <td style={{ padding: "8px 10px", fontWeight: 700 }}>
                    <span style={{ cursor: "pointer", color: "var(--text)" }} onMouseEnter={e => (e.currentTarget.style.color="var(--win-text)")} onMouseLeave={e => (e.currentTarget.style.color="var(--text)")} onClick={() => openEditModal(m)}>
                      {m.nickname}
                      {m.warningCount > 0 && <span style={{ fontSize: 11, fontWeight: 800, marginLeft: 6, color: "#f1948a" }}>⚠️{m.warningCount}</span>}
                    </span>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center", fontWeight: 800,
                    color: (m as any).aramGamesSince >= 6 ? "var(--win-text)" : "var(--loss-text)" }}>
                    {(m as any).aramGamesSince}판
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center", fontWeight: 800,
                    color: (m as any).normalGamesSince >= 3 ? "var(--win-text)" : "var(--loss-text)" }}>
                    {(m as any).normalGamesSince}판
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center", fontSize: 12, color: "var(--muted)" }}>
                    {(m as any).lastAchievedAt ? (() => { const [y,mo,d] = (m as any).lastAchievedAt.split("-").map(Number); return `${mo}/${d}`; })() : "-"}
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center", fontSize: 12 }}>
                    {(() => {
                      const last = (m as any).lastAchievedAt;
                      if (!last) return <span style={{ color: "var(--loss-text)" }}>달성 이력 없음</span>;
                      const [y, mo, d] = last.split("-").map(Number);
                      const deadline = new Date(y, mo - 1, d + 14);
                      const today = new Date(); today.setHours(0,0,0,0);
                      const daysLeft = Math.ceil((deadline.getTime() - today.getTime()) / (24 * 60 * 60 * 1000));
                      const label = `${deadline.getMonth()+1}/${deadline.getDate()}`;
                      const color = daysLeft <= 0 ? "var(--loss-text)" : daysLeft <= 3 ? "#f39c12" : "var(--muted)";
                      return <span style={{ color, fontWeight: daysLeft <= 3 ? 800 : 400 }}>
                        {label}{daysLeft <= 0 ? ` (초과 ${Math.abs(daysLeft)}일)` : ` (${daysLeft}일 남음)`}
                      </span>;
                    })()}
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    <button className="sync-btn" style={{ fontSize: 11, padding: "2px 10px" }}
                      onClick={() => setInactiveLogModal({ memberId: m.id, nickname: m.nickname, logs: m.recentLogs ?? [] })}>
                      로그
                    </button>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    {(user?.role === "admin" || user?.role === "subadmin") && (
                      <button className="sync-btn" style={{ fontSize: 11, padding: "2px 10px" }}
                        onClick={() => {
                          const today = new Date(Date.now() + 9*60*60*1000).toISOString().slice(0, 10);
                          setAchieveDate(today);
                          setAchievePickerId(m.id);
                        }}>
                        갱신
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : specialFilter === "rookie" ? (
        <div className="ui-table-wrap">
          <table className="ui-table">
            <thead>
              <tr>
                <th style={{ textAlign: "left", padding: "6px 10px" }}>닉네임</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>가입일자</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>파티참여 (자유/내전)</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>파티 로그</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>전환</th>
              </tr>
            </thead>
            <tbody>
              {pagedMembers.map((m) => {
                const cnt = m.rookiePartyCount ?? 0;
                const circles = Array.from({ length: 3 }, (_, i) => i < cnt ? "O" : "X");
                const rookieNickSet2 = new Set(members.filter(x => x.position === '수습').map(x => x.nickname));
                const playedUnique = new Set(
                  (m.rookieSessionLogs ?? []).flatMap((log: any) => log.members ?? []).filter((n: string) => !rookieNickSet2.has(n))
                ).size;
                const canPromote = cnt >= 3 && playedUnique >= 3;
                return (
                  <tr key={m.id}>
                    <td style={{ padding: "8px 10px", fontWeight: 700 }}>
                      <span style={{ cursor: "pointer", color: "var(--text)" }} onMouseEnter={e => (e.currentTarget.style.color="var(--win-text)")} onMouseLeave={e => (e.currentTarget.style.color="var(--text)")} onClick={() => openEditModal(m)}>
                      {(() => {
                        const cnt = m.rookiePartyCount ?? 0;
                        const canPromote = cnt >= 3;
                        const createdAt = m.createdAt ? new Date(m.createdAt) : null;
                        const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                        const overdue = createdAt && createdAt < oneWeekAgo && !canPromote;
                        const color = canPromote ? '#2ecc71' : overdue ? '#f1948a' : 'var(--text)';
                        const rookieNickSet = new Set(members.filter(x => x.position === '수습').map(x => x.nickname));
                        const playedCount = new Set(
                          (m.rookieSessionLogs ?? []).flatMap((log: any) => log.members ?? []).filter((n: string) => !rookieNickSet.has(n))
                        ).size;
                        return <span style={{ color }}>{m.nickname}{cnt >= 3 && playedCount >= 10 && <span title="파티참여 OOO + 같이 플레이한 클랜원 10명 이상"> ✅</span>}</span>;
                      })()}
                      </span>
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "center", color: "var(--muted)" }}>{m.createdAt ? m.createdAt.slice(0, 10) : "-"}</td>
                    <td style={{ padding: "8px 10px", textAlign: "center", fontSize: 15, letterSpacing: 4 }}>
                      {circles.map((v, i) => (
                        <span key={i} style={{ fontWeight: 800, color: v === "O" ? "#4fc3f7" : "#f1948a" }}>{v} </span>
                      ))}
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "center" }}>
                      <button className="sync-btn" style={{ fontSize: 11, padding: "2px 10px" }}
                        onClick={() => setRookieLogModal({ memberId: m.id, nickname: m.nickname, logs: m.rookieSessionLogs ?? [] })}>
                        로그
                      </button>
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "center" }}>
                      {isAdmin && (
                        <button
                          className="sync-btn"
                          style={{ fontSize: 11, padding: "2px 10px", opacity: canPromote ? 1 : 0.4, cursor: canPromote ? "pointer" : "not-allowed" }}
                          onClick={async () => {
                            if (!canPromote) { alert("파티 참여 3판 + 같이 플레이한 클랜원 3명을 충족해야 클랜원으로 전환할 수 있습니다."); return; }
                            if (!confirm(`${m.nickname}을(를) 클랜원으로 전환하시겠습니까?`)) return;
                            const res = await fetch("/api/userinfo/member", {
                              method: "PUT",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({ id: m.id, position: "클랜원", status: m.status ?? "active", birthYear: m.birthYear, birthDate: m.birthDate, gender: m.gender, mainLine: m.mainLine, subLine: m.subLine, statusNote: m.statusNote }),
                            });
                            if (res.ok) loadMembers();
                            else alert("전환 실패");
                          }}>
                          클랜원 전환
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : specialFilter === "withdraw" ? (
        <div className="ui-table-wrap">
          <table className="ui-table">
            <thead>
              <tr>
                <th style={{ textAlign: "left", padding: "6px 10px" }}>닉네임</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>탈퇴일</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>탈퇴사유</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>블랙</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>관리</th>
              </tr>
            </thead>
            <tbody>
              {pagedMembers.map((m) => (
                <tr key={m.id} style={{ borderBottom: "1px solid var(--border)", background: (m as any).isBlacklisted ? "rgba(231,76,60,0.06)" : undefined }}>
                  <td style={{ padding: "8px 10px", fontWeight: 700 }}>
                    <span style={{ cursor: "pointer", color: (m as any).isBlacklisted ? "#f1948a" : "var(--text)" }} onMouseEnter={e => (e.currentTarget.style.color="var(--win-text)")} onMouseLeave={e => (e.currentTarget.style.color=(m as any).isBlacklisted ? "#f1948a" : "var(--text)")} onClick={() => openEditModal(m)}>
                      {m.nickname}
                    </span>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center", color: "var(--muted)", fontSize: 12 }}>
                    {(m as any).withdrewAt ? (m as any).withdrewAt.slice(0, 10) : "-"}
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    {m.statusNote
                      ? <button className="withdraw-btn" onClick={() => { setWithdrawReasonEdit(m.statusNote!); setWithdrawReasonModal({ nickname: m.nickname, reason: m.statusNote!, memberId: m.id, withdrewAt: (m as any).withdrewAt ?? "" }); }}>+ 사유</button>
                      : <span style={{ color: "var(--muted)", fontSize: 12 }}>-</span>}
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    <button className={`black-btn${(m as any).isBlacklisted ? " on" : ""}`} onClick={() => openBlacklistModal(m)}>
                      {(m as any).isBlacklisted ? "💀 블랙" : "+ 블랙"}
                    </button>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center", whiteSpace: "nowrap" }}>
                    {isAdmin && (
                      <button className="sync-btn" style={{ fontSize: 11, padding: "2px 10px" }}
                        onClick={async () => {
                          if (!confirm(`"${m.nickname}"을(를) 클랜원으로 재가입 처리하시겠습니까?`)) return;
                          const res = await fetch("/api/userinfo/member", {
                            method: "PUT",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ id: m.id, position: m.position === "수습" ? "수습" : "클랜원", status: "active", birthYear: m.birthYear, birthDate: m.birthDate, gender: m.gender, mainLine: m.mainLine, subLine: m.subLine, statusNote: null }),
                          });
                          if (res.ok) loadMembers();
                          else alert("전환 실패");
                        }}>클랜원 전환</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
      <div className="ui-table-wrap">
        <table className="ui-table">
          <thead>
            <tr>
                <th style={{ textAlign: "left", padding: "6px 10px" }}>닉네임</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>활동티어</th>
                <th style={{ textAlign: "right", padding: "6px 10px" }}>포인트</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>솔로랭크</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>직책</th>
                <th style={{ textAlign: "center", padding: "6px 10px" }}>활동상태</th>
                <th style={{ textAlign: "right", padding: "6px 10px" }}>관리</th>
            </tr>
          </thead>
          <tbody>
            {pagedMembers.map((m) => {
              const at = activityTier(m.totalPoints);
              return (
                <tr key={m.id}>
                  <td style={{ padding: "8px 10px", fontWeight: 700 }}>
                    <span style={{ cursor: "pointer", color: "var(--text)" }} onMouseEnter={e => (e.currentTarget.style.color="var(--win-text)")} onMouseLeave={e => (e.currentTarget.style.color="var(--text)")} onClick={() => openEditModal(m)}>
                      {m.nickname}
                      {m.birthYear && <span style={{ fontSize: 11, color: "var(--muted)", marginLeft: 5, fontWeight: 400 }}>{String(m.birthYear).slice(2)}년생</span>}
                      {m.warningCount > 0 && <span style={{ fontSize: 11, fontWeight: 800, marginLeft: 6, color: "#f1948a" }}>⚠️{m.warningCount}</span>}
                    </span>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    {at ? (
                      <span style={{ fontSize: 11, fontWeight: 800, padding: "2px 7px", borderRadius: 5,
                        background: `${at.color}22`, color: at.color, border: `1px solid ${at.color}55` }}>
                        {at.label}
                      </span>
                    ) : "-"}
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 800,
                    color: m.totalPoints > 0 ? "var(--win-text)" : "var(--muted)" }}>
                    {m.totalPoints}P
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    {m.tier
                      ? <span className={`tier-badge tier-${m.tier.tier.toLowerCase()}`}>{tierLabel(m.tier)}</span>
                    : <span style={{ color: "var(--muted)" }}>-</span>}
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    {m.position !== "일반" ? (
                      <span style={{ fontSize: 11, fontWeight: 800, padding: "2px 6px", borderRadius: 5,
                        background: m.position === "수습" ? "rgba(230,126,34,0.18)" : m.position === "부운영진" ? "rgba(155,89,182,0.18)" : m.position === "운영진" ? "rgba(255,105,180,0.18)" : "rgba(83,131,232,0.18)",
                        color: m.position === "수습" ? "#e67e22" : m.position === "부운영진" ? "#c39bd3" : m.position === "운영진" ? "#ff69b4" : "var(--win-text)" }}>
                        {m.position}
                      </span>
                    ) : <span style={{ fontSize: 11, fontWeight: 800, padding: "2px 6px", borderRadius: 5, background: "rgba(83,131,232,0.18)", color: "var(--win-text)" }}>클랜원</span>}
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    {m.status === "leave" ? (
                      <span style={{ fontSize: 11, fontWeight: 800, padding: "2px 6px", borderRadius: 5,
                        background: "rgba(46,204,113,0.18)", color: "#2ecc71" }}>
                        {m.statusNote ? `외출 ${m.statusNote}` : "외출"}
                      </span>
                    ) : (
                      <span style={{ fontSize: 11, fontWeight: 800, padding: "2px 6px", borderRadius: 5,
                        background: "rgba(83,131,232,0.18)", color: "var(--win-text)" }}>활동</span>
                    )}
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "right", whiteSpace: "nowrap" }}>
                    <button className="warn-btn" onClick={() => openWarnModal(m)}>경고</button>
                    {" "}
                    <button className="black-btn" onClick={() => openBlacklistModal(m)}>블랙</button>
                    {" "}
                    <button className="withdraw-btn" onClick={() => { setWithdrawReason(""); setWithdrawModal({ member: m }); }}>탈퇴</button>
                    {" "}
                    <button className="del-btn small" onClick={() => remove("member", m.id, m.nickname)}>삭제</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      )}
      </div>
      </>)}
    </div>
  );
}
